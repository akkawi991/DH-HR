import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  getNotifications,
  getUnreadCount,
  markNotificationRead,
  markAllNotificationsRead,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface NotificationsProps {
  user: User;
}

export function Notifications({ user }: NotificationsProps) {
  const [refresh, setRefresh] = useState(0);
  const notifications = getNotifications(user.id);
  const unreadCount = getUnreadCount(user.id);

  const handleMarkRead = (id: string) => {
    markNotificationRead(id);
    setRefresh(refresh + 1);
  };

  const handleMarkAllRead = () => {
    markAllNotificationsRead(user.id);
    setRefresh(refresh + 1);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الإشعارات</h1>
          <p className="text-slate-500 mt-1">مركز الإشعارات</p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" onClick={handleMarkAllRead}>
            تحديد الكل كمقروء
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">الإشعارات ({notifications.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {notifications.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد إشعارات</p>
          ) : (
            <div className="space-y-3">
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                    notif.read ? "bg-slate-50 border-slate-200" : "bg-indigo-50 border-indigo-200"
                  }`}
                  onClick={() => handleMarkRead(notif.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{notif.title}</div>
                    {!notif.read && (
                      <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                    )}
                  </div>
                  <div className="text-sm text-slate-600 mt-1">{notif.message}</div>
                  <div className="text-xs text-slate-400 mt-2">
                    {new Date(notif.createdAt).toLocaleString("ar")}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}