import { useState } from "react";
import { Login } from "@/components/Login";
import { Dashboard } from "@/components/Dashboard";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { LeaveRequests } from "@/components/LeaveRequests";
import { Overtime } from "@/components/Overtime";
import { Inquiries } from "@/components/Inquiries";
import { Complaints } from "@/components/Complaints";
import { Announcements } from "@/components/Announcements";
import { Summons } from "@/components/Summons";
import { Notifications } from "@/components/Notifications";
import { Employees } from "@/components/Employees";
import { Users } from "@/components/Users";
import { Organization } from "@/components/Organization";
import { Approvals } from "@/components/Approvals";
import { logout, currentUserInfo } from "@/lib/data";
import type { User } from "@/lib/data";

export default function App() {
  const [user, setUser] = useState<User | null>(() => currentUserInfo());
  const [currentPage, setCurrentPage] = useState("home");
  const [showNotifications, setShowNotifications] = useState(false);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setCurrentPage("home");
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setCurrentPage("home");
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    setShowNotifications(false);
  };

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  const getNavItems = () => {
    const items = [
      { id: "home", label: "الرئيسية", icon: "home" },
      { id: "leave", label: "الإجازات", icon: "calendar" },
      { id: "overtime", label: "العمل الإضافي", icon: "clock" },
    ];

    if (user.role === "EMPLOYEE") {
      items.push(
        { id: "inquiries", label: "الاستفسارات", icon: "help" },
        { id: "complaints", label: "الشكاوى", icon: "alert" }
      );
    }

    if (user.role === "SECTION_MANAGER" || user.role === "DEPARTMENT_MANAGER") {
      items.push(
        { id: "inquiries", label: "الاستفسارات", icon: "help" },
        { id: "complaints", label: "الشكاوى", icon: "alert" }
      );
    }

    if (user.role === "HR_OFFICER" || user.role === "HR_MANAGER") {
      items.push(
        { id: "inquiries", label: "الاستفسارات", icon: "help" },
        { id: "complaints", label: "الشكاوى", icon: "alert" },
        { id: "announcements", label: "الإعلانات والتعاميم", icon: "megaphone" },
        { id: "summons", label: "الاستدعاءات", icon: "file" },
        { id: "employees", label: "الموظفون", icon: "users" }
      );
    }

    if (user.role === "HR_MANAGER") {
      items.push(
        { id: "users", label: "المستخدمون", icon: "user" },
        { id: "organization", label: "الهيكل التنظيمي", icon: "tree" }
      );
    }

    if (user.role === "GENERAL_MANAGER") {
      items.push({ id: "approvals", label: "الموافقات", icon: "check" });
    }

    if (user.role === "HR_MANAGER" || user.role === "HR_OFFICER") {
      items.push({ id: "approvals", label: "الموافقات", icon: "check" });
    }

    items.push({ id: "notifications", label: "الإشعارات", icon: "bell" });

    return items;
  };

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <Dashboard user={user} onNavigate={handleNavigate} />;
      case "leave":
        return <LeaveRequests user={user} />;
      case "overtime":
        return <Overtime user={user} />;
      case "inquiries":
        return <Inquiries user={user} />;
      case "complaints":
        return <Complaints user={user} />;
      case "announcements":
        return <Announcements user={user} />;
      case "summons":
        return <Summons user={user} />;
      case "employees":
        return <Employees user={user} />;
      case "users":
        return <Users user={user} />;
      case "organization":
        return <Organization user={user} />;
      case "approvals":
        return <Approvals user={user} />;
      case "notifications":
        return <Notifications user={user} />;
      default:
        return <Dashboard user={user} onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex">
      <Sidebar
        navItems={getNavItems()}
        currentPage={currentPage}
        onNavigate={handleNavigate}
        user={user}
      />
      <div className="flex-1 flex flex-col">
        <TopBar
          user={user}
          onLogout={handleLogout}
          onOpenNotifications={() => {
            setShowNotifications(true);
            setCurrentPage("notifications");
          }}
          onNavigate={handleNavigate}
        />
        <main className="flex-1 p-6 overflow-y-auto">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}