import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getRoleLabel,
  canManageUsers,
  createUser,
  updateUserRole,
  toggleUserActive,
  resetPassword,
} from "@/lib/data";
import type { User, Role } from "@/lib/data";

interface UsersProps {
  user: User;
}

export function Users({ user }: UsersProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);

  const canManage = canManageUsers(user.role);

  const handleRoleChange = (userId: string, newRole: Role) => {
    const result = updateUserRole(user, userId, newRole);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  const handleToggleActive = (userId: string) => {
    const result = toggleUserActive(user, userId);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  const handleResetPassword = (userId: string) => {
    const newPassword = prompt("أدخل كلمة المرور الجديدة:");
    if (newPassword) {
      const result = resetPassword(user, userId, newPassword);
      if (result.success) {
        setRefresh(refresh + 1);
      } else {
        setError(result.message);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">إدارة المستخدمين</h1>
          <p className="text-slate-500 mt-1">إدارة حسابات المستخدمين والأدوار</p>
        </div>
        {canManage && (
          <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
            مستخدم جديد
          </Button>
        )}
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">المستخدمون ({dataStore.users.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-right p-3">الموظف</th>
                  <th className="text-right p-3">اسم المستخدم</th>
                  <th className="text-right p-3">البريد الإلكتروني</th>
                  <th className="text-right p-3">الدور</th>
                  <th className="text-right p-3">الحالة</th>
                  <th className="text-right p-3">آخر تسجيل دخول</th>
                  <th className="text-right p-3">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {dataStore.users.map((u) => {
                  const emp = getEmployee(u.employeeId);
                  return (
                    <tr key={u.id} className="border-b border-slate-100">
                      <td className="p-3">{emp?.name || "-"}</td>
                      <td className="p-3">{u.username}</td>
                      <td className="p-3">{u.email}</td>
                      <td className="p-3">
                        {canManage ? (
                          <select
                            value={u.role}
                            onChange={(e) => handleRoleChange(u.id, e.target.value as Role)}
                            className="p-1 border rounded text-sm"
                          >
                            <option value="EMPLOYEE">موظف</option>
                            <option value="SECTION_MANAGER">مدير قسم</option>
                            <option value="DEPARTMENT_MANAGER">مدير إدارة</option>
                            <option value="HR_OFFICER">موظف موارد بشرية</option>
                            <option value="HR_MANAGER">مدير موارد بشرية</option>
                            <option value="GENERAL_MANAGER">مدير عام</option>
                          </select>
                        ) : (
                          getRoleLabel(u.role)
                        )}
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-1 rounded-full text-xs ${u.active ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>
                          {u.active ? "نشط" : "معطل"}
                        </span>
                      </td>
                      <td className="p-3 text-slate-500">
                        {u.lastLogin ? new Date(u.lastLogin).toLocaleDateString("ar") : "-"}
                      </td>
                      <td className="p-3">
                        {canManage && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleResetPassword(u.id)}
                            >
                              إعادة تعيين
                            </Button>
                            <Button
                              size="sm"
                              variant={u.active ? "destructive" : "outline"}
                              onClick={() => handleToggleActive(u.id)}
                            >
                              {u.active ? "تعطيل" : "تفعيل"}
                            </Button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {showForm && (
        <UserForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => {
            setShowForm(false);
            setRefresh(refresh + 1);
          }}
        />
      )}
    </div>
  );
}

function UserForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("EMPLOYEE");
  const [employeeId, setEmployeeId] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createUser(user, {
      username,
      password,
      email,
      role,
      employeeId,
    });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">مستخدم جديد</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">الموظف *</label>
            <select
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="">اختر الموظف</option>
              {dataStore.employees
                .filter((e) => e.active && !dataStore.users.find((u) => u.employeeId === e.id))
                .map((emp) => (
                  <option key={emp.id} value={emp.id}>{emp.name}</option>
                ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">اسم المستخدم *</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">كلمة المرور *</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">البريد الإلكتروني *</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الدور *</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as Role)}
              className="w-full p-2 border rounded-lg"
            >
              <option value="EMPLOYEE">موظف</option>
              <option value="SECTION_MANAGER">مدير قسم</option>
              <option value="DEPARTMENT_MANAGER">مدير إدارة</option>
              <option value="HR_OFFICER">موظف موارد بشرية</option>
              <option value="HR_MANAGER">مدير موارد بشرية</option>
              <option value="GENERAL_MANAGER">مدير عام</option>
            </select>
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">إنشاء</Button>
          </div>
        </form>
      </div>
    </div>
  );
}