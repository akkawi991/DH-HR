import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getStatusLabel,
  getStatusColor,
  canViewAllInquiries,
  createInquiry,
  updateInquiryStatus,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface InquiriesProps {
  user: User;
}

export function Inquiries({ user }: InquiriesProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");

  const canViewAll = canViewAllInquiries(user.role);
  const visibleInquiries = canViewAll
    ? dataStore.inquiries
    : dataStore.inquiries.filter((i) => i.employeeId === user.employeeId);

  const handleStatusChange = (inquiryId: string, status: "IN_PROGRESS" | "ANSWERED" | "CLOSED", response?: string) => {
    const result = updateInquiryStatus(user, inquiryId, status, response);
    if (!result.success) setError(result.message);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الاستفسارات</h1>
          <p className="text-slate-500 mt-1">إدارة استفسارات الموظفين</p>
        </div>
        <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
          استفسار جديد
        </Button>
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">الاستفسارات ({visibleInquiries.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {visibleInquiries.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد استفسارات</p>
          ) : (
            <div className="space-y-4">
              {visibleInquiries.map((inq) => {
                const emp = getEmployee(inq.employeeId);
                return (
                  <div key={inq.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{inq.number}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(inq.status)}`}>
                        {getStatusLabel(inq.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div>الموظف: {emp?.name}</div>
                      <div>الفئة: {inq.category}</div>
                      <div>الموضوع: {inq.subject}</div>
                      <div className="mt-2">{inq.question}</div>
                      {inq.response && (
                        <div className="mt-2 p-2 bg-emerald-50 rounded text-emerald-700">
                          <strong>الرد:</strong> {inq.response}
                        </div>
                      )}
                    </div>
                    {canViewAll && (
                      <div className="flex gap-2 mt-3">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleStatusChange(inq.id, "IN_PROGRESS")}
                        >
                          قيد المعالجة
                        </Button>
                        <Button
                          size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => {
                            const response = prompt("أدخل الرد:");
                            if (response) handleStatusChange(inq.id, "ANSWERED", response);
                          }}
                        >
                          رد
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleStatusChange(inq.id, "CLOSED")}
                        >
                          إغلاق
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {showForm && (
        <InquiryForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => setShowForm(false)}
        />
      )}
    </div>
  );
}

function InquiryForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [category, setCategory] = useState("");
  const [subject, setSubject] = useState("");
  const [question, setQuestion] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createInquiry(user, { category, subject, question });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">استفسار جديد</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">الفئة *</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="">اختر الفئة</option>
              <option value="الراتب">الراتب</option>
              <option value="رصيد الإجازات">رصيد الإجازات</option>
              <option value="الحضور والانصراف">الحضور والانصراف</option>
              <option value="العمل الإضافي">العمل الإضافي</option>
              <option value="العقد">العقد</option>
              <option value="الرواتب والأجور">الرواتب والأجور</option>
              <option value="البيانات الشخصية">البيانات الشخصية</option>
              <option value="أخرى">أخرى</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الموضوع *</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">السؤال *</label>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="w-full p-2 border rounded-lg"
              rows={4}
              required
            />
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">إرسال</Button>
          </div>
        </form>
      </div>
    </div>
  );
}