import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getStatusLabel,
  getStatusColor,
  canCreateAnnouncements,
  createAnnouncement,
  isAnnouncementVisibleToUser,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface AnnouncementsProps {
  user: User;
}

export function Announcements({ user }: AnnouncementsProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");

  const canCreate = canCreateAnnouncements(user.role);
  const visibleAnnouncements = dataStore.announcements.filter((a) => isAnnouncementVisibleToUser(a, user));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الإعلانات والتعاميم</h1>
          <p className="text-slate-500 mt-1">إدارة الإعلانات والتعاميم</p>
        </div>
        {canCreate && (
          <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
            إعلان جديد
          </Button>
        )}
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">الإعلانات ({visibleAnnouncements.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {visibleAnnouncements.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد إعلانات</p>
          ) : (
            <div className="space-y-4">
              {visibleAnnouncements.map((ann) => {
                const creator = getEmployee(ann.createdBy);
                return (
                  <div key={ann.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{ann.title}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(ann.status)}`}>
                        {getStatusLabel(ann.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div className="mb-2">{ann.message}</div>
                      <div className="text-xs text-slate-400">
                        النوع: {ann.type === "ANNOUNCEMENT" ? "إعلان" : "تعميم"} | 
                        بواسطة: {creator?.name} | 
                        النشر: {new Date(ann.publishDate).toLocaleDateString("ar")}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {showForm && (
        <AnnouncementForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => setShowForm(false)}
        />
      )}
    </div>
  );
}

function AnnouncementForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [title, setTitle] = useState("");
  const [type, setType] = useState<"ANNOUNCEMENT" | "CIRCULAR">("ANNOUNCEMENT");
  const [message, setMessage] = useState("");
  const [targetType, setTargetType] = useState<"ALL" | "DEPARTMENT" | "SECTION" | "EMPLOYEE">("ALL");
  const [targetId, setTargetId] = useState("");
  const [publishDate, setPublishDate] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createAnnouncement(user, {
      title,
      type,
      message,
      targetType,
      targetId: targetType === "ALL" ? undefined : targetId,
      publishDate,
      expiryDate,
    });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">إعلان جديد</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">العنوان *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">النوع *</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as "ANNOUNCEMENT" | "CIRCULAR")}
              className="w-full p-2 border rounded-lg"
            >
              <option value="ANNOUNCEMENT">إعلان</option>
              <option value="CIRCULAR">تعميم</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الرسالة *</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-2 border rounded-lg"
              rows={4}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الجمهور المستهدف *</label>
            <select
              value={targetType}
              onChange={(e) => setTargetType(e.target.value as "ALL" | "DEPARTMENT" | "SECTION" | "EMPLOYEE")}
              className="w-full p-2 border rounded-lg"
            >
              <option value="ALL">الجميع</option>
              <option value="DEPARTMENT">إدارة</option>
              <option value="SECTION">قسم</option>
              <option value="EMPLOYEE">موظف محدد</option>
            </select>
          </div>
          {targetType !== "ALL" && (
            <div>
              <label className="block text-sm font-medium mb-1">الهدف *</label>
              <select
                value={targetId}
                onChange={(e) => setTargetId(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              >
                <option value="">اختر الهدف</option>
                {targetType === "DEPARTMENT" && dataStore.orgUnits.filter((u) => u.type === "DEPARTMENT").map((u) => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
                {targetType === "SECTION" && dataStore.orgUnits.filter((u) => u.type === "SECTION").map((u) => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
                {targetType === "EMPLOYEE" && dataStore.employees.filter((e) => e.active).map((e) => (
                  <option key={e.id} value={e.id}>{e.name}</option>
                ))}
              </select>
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">تاريخ النشر *</label>
              <input
                type="date"
                value={publishDate}
                onChange={(e) => setPublishDate(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">تاريخ الانتهاء *</label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">نشر</Button>
          </div>
        </form>
      </div>
    </div>
  );
}