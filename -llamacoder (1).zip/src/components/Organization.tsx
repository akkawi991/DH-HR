import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  canManageOrg,
  createOrgUnit,
  updateOrgUnitManager,
  updateEmployeeManager,
  updateEmployeeDepartment,
  updateEmployeeSection,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface OrganizationProps {
  user: User;
}

export function Organization({ user }: OrganizationProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);

  const canManage = canManageOrg(user.role);

  const handleUnitManagerChange = (unitId: string, managerId: string) => {
    const result = updateOrgUnitManager(user, unitId, managerId || null);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  const handleEmployeeManagerChange = (employeeId: string, managerId: string) => {
    const result = updateEmployeeManager(user, employeeId, managerId || null);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  const handleEmployeeDeptChange = (employeeId: string, deptId: string) => {
    const result = updateEmployeeDepartment(user, employeeId, deptId || null);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  const handleEmployeeSectionChange = (employeeId: string, sectionId: string) => {
    const result = updateEmployeeSection(user, employeeId, sectionId || null);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  const departments = dataStore.orgUnits.filter((u) => u.type === "DEPARTMENT");
  const sections = dataStore.orgUnits.filter((u) => u.type === "SECTION");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الهيكل التنظيمي</h1>
          <p className="text-slate-500 mt-1">إدارة الهيكل التنظيمي للشركة</p>
        </div>
        {canManage && (
          <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
            إضافة وحدة
          </Button>
        )}
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">الإدارات والأقسام</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {departments.map((dept) => {
                const deptManager = getEmployee(dept.managerId);
                const deptSections = sections.filter((s) => s.parentId === dept.id);
                return (
                  <div key={dept.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{dept.name}</div>
                      <div className="text-xs text-slate-500">{dept.code}</div>
                    </div>
                    <div className="text-sm text-slate-600 mb-2">
                      المدير: {deptManager?.name || "غير محدد"}
                    </div>
                    {canManage && (
                      <select
                        value={dept.managerId || ""}
                        onChange={(e) => handleUnitManagerChange(dept.id, e.target.value)}
                        className="w-full p-2 border rounded-lg text-sm mb-3"
                      >
                        <option value="">اختر المدير</option>
                        {dataStore.employees.filter((e) => e.active).map((emp) => (
                          <option key={emp.id} value={emp.id}>{emp.name}</option>
                        ))}
                      </select>
                    )}
                    <div className="space-y-2">
                      {deptSections.map((section) => {
                        const sectionManager = getEmployee(section.managerId);
                        return (
                          <div key={section.id} className="p-3 bg-white rounded-lg border border-slate-200">
                            <div className="flex items-center justify-between">
                              <div className="text-sm font-medium">{section.name}</div>
                              <div className="text-xs text-slate-500">{section.code}</div>
                            </div>
                            <div className="text-sm text-slate-600 mt-1">
                              المدير: {sectionManager?.name || "غير محدد"}
                            </div>
                            {canManage && (
                              <select
                                value={section.managerId || ""}
                                onChange={(e) => handleUnitManagerChange(section.id, e.target.value)}
                                className="w-full p-2 border rounded-lg text-sm mt-2"
                              >
                                <option value="">اختر المدير</option>
                                {dataStore.employees.filter((e) => e.active).map((emp) => (
                                  <option key={emp.id} value={emp.id}>{emp.name}</option>
                                ))}
                              </select>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">الموظفون والمديرون المباشرون</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dataStore.employees.filter((e) => e.active).map((emp) => {
                const manager = getEmployee(emp.managerId);
                return (
                  <div key={emp.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="font-medium">{emp.name}</div>
                    <div className="text-sm text-slate-600 mt-1">{emp.jobTitle}</div>
                    {canManage && (
                      <div className="grid grid-cols-3 gap-2 mt-3">
                        <select
                          value={emp.departmentId || ""}
                          onChange={(e) => handleEmployeeDeptChange(emp.id, e.target.value)}
                          className="p-2 border rounded-lg text-sm"
                        >
                          <option value="">الإدارة</option>
                          {departments.map((d) => (
                            <option key={d.id} value={d.id}>{d.name}</option>
                          ))}
                        </select>
                        <select
                          value={emp.sectionId || ""}
                          onChange={(e) => handleEmployeeSectionChange(emp.id, e.target.value)}
                          className="p-2 border rounded-lg text-sm"
                        >
                          <option value="">القسم</option>
                          {sections.map((s) => (
                            <option key={s.id} value={s.id}>{s.name}</option>
                          ))}
                        </select>
                        <select
                          value={emp.managerId || ""}
                          onChange={(e) => handleEmployeeManagerChange(emp.id, e.target.value)}
                          className="p-2 border rounded-lg text-sm"
                        >
                          <option value="">المدير المباشر</option>
                          {dataStore.employees.filter((e) => e.active && e.id !== emp.id).map((e) => (
                            <option key={e.id} value={e.id}>{e.name}</option>
                          ))}
                        </select>
                      </div>
                    )}
                    {!canManage && (
                      <div className="text-sm text-slate-600 mt-2">
                        المدير المباشر: {manager?.name || "غير محدد"}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {showForm && (
        <OrgUnitForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => {
            setShowForm(false);
            setRefresh(refresh + 1);
          }}
        />
      )}
    </div>
  );
}

function OrgUnitForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [type, setType] = useState<"COMPANY" | "DEPARTMENT" | "SECTION">("DEPARTMENT");
  const [parentId, setParentId] = useState("");
  const [managerId, setManagerId] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createOrgUnit(user, {
      name,
      code,
      type,
      parentId: parentId || null,
      managerId: managerId || null,
    });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">إضافة وحدة تنظيمية</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">الاسم *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الكود *</label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">النوع *</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as "COMPANY" | "DEPARTMENT" | "SECTION")}
              className="w-full p-2 border rounded-lg"
            >
              <option value="COMPANY">شركة</option>
              <option value="DEPARTMENT">إدارة</option>
              <option value="SECTION">قسم</option>
            </select>
          </div>
          {type !== "COMPANY" && (
            <div>
              <label className="block text-sm font-medium mb-1">الوحدة الأم</label>
              <select
                value={parentId}
                onChange={(e) => setParentId(e.target.value)}
                className="w-full p-2 border rounded-lg"
              >
                <option value="">بدون</option>
                {dataStore.orgUnits
                  .filter((u) => u.type === "COMPANY" || (type === "SECTION" && u.type === "DEPARTMENT"))
                  .map((u) => (
                    <option key={u.id} value={u.id}>{u.name}</option>
                  ))}
              </select>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium mb-1">المدير</label>
            <select
              value={managerId}
              onChange={(e) => setManagerId(e.target.value)}
              className="w-full p-2 border rounded-lg"
            >
              <option value="">بدون</option>
              {dataStore.employees.filter((e) => e.active).map((emp) => (
                <option key={emp.id} value={emp.id}>{emp.name}</option>
              ))}
            </select>
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">إنشاء</Button>
          </div>
        </form>
      </div>
    </div>
  );
}