import { Button } from "@/components/ui/button";
import { getEmployee, getUnreadCount } from "@/lib/data";
import type { User } from "@/lib/data";

interface TopBarProps {
  user: User;
  onLogout: () => void;
  onOpenNotifications: () => void;
  onNavigate: (page: string) => void;
}

export function TopBar({ user, onLogout, onOpenNotifications, onNavigate }: TopBarProps) {
  const emp = getEmployee(user.employeeId);
  const unreadCount = getUnreadCount(user.id);

  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
      <div>
        <h2 className="text-lg font-semibold text-slate-900">DH HR — Human Resources</h2>
      </div>
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenNotifications}
          className="relative p-2 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <span className="text-xl">🔔</span>
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>
        <div className="text-sm text-slate-600">
          {emp?.name}
        </div>
        <Button variant="outline" size="sm" onClick={onLogout}>
          تسجيل الخروج
        </Button>
      </div>
    </header>
  );
}