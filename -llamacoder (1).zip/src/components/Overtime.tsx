import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getStatusLabel,
  getStatusColor,
  getScopeEmployeeIds,
  canCreateOvertime,
  createOvertimeAssignment,
  getOvertimeAllowedActions,
  performOvertimeAction,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface OvertimeProps {
  user: User;
}

export function Overtime({ user }: OvertimeProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);

  const scopeIds = getScopeEmployeeIds(user);
  const canCreate = canCreateOvertime(user.role);
  const visibleAssignments = dataStore.overtime.filter((o) => scopeIds.includes(o.employeeId));

  const handleAction = (assignmentId: string, action: string) => {
    let comment: string | undefined;
    if (action === "REJECT") {
      comment = prompt("سبب الرفض:");
      if (!comment) return;
    }
    const result = performOvertimeAction(user, assignmentId, action, comment);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">العمل الإضافي</h1>
          <p className="text-slate-500 mt-1">إدارة تكليفات العمل الإضافي</p>
        </div>
        {canCreate && (
          <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
            تكليف إضافي
          </Button>
        )}
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">التكليفات ({visibleAssignments.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {visibleAssignments.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد تكليفات</p>
          ) : (
            <div className="space-y-4">
              {visibleAssignments.map((assignment) => {
                const emp = getEmployee(assignment.employeeId);
                const actions = getOvertimeAllowedActions(user, assignment);
                return (
                  <div key={assignment.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{assignment.number}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(assignment.status)}`}>
                        {getStatusLabel(assignment.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div>الموظف: {emp?.name}</div>
                      <div>التاريخ: {assignment.date}</div>
                      <div>الوقت: {assignment.startTime} - {assignment.endTime}</div>
                      <div>الساعات: {assignment.hours}</div>
                      <div>السبب: {assignment.reason}</div>
                    </div>
                    {actions.length > 0 && (
                      <div className="flex gap-2 mt-3">
                        {actions.includes("APPROVE") && (
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-700"
                            onClick={() => handleAction(assignment.id, "APPROVE")}
                          >
                            موافقة
                          </Button>
                        )}
                        {actions.includes("REJECT") && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleAction(assignment.id, "REJECT")}
                          >
                            رفض
                          </Button>
                        )}
                        {actions.includes("FORWARD") && (
                          <Button
                            size="sm"
                            className="bg-purple-600 hover:bg-purple-700"
                            onClick={() => handleAction(assignment.id, "FORWARD")}
                          >
                            تحويل للمدير العام
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {showForm && (
        <OvertimeForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => {
            setShowForm(false);
            setRefresh(refresh + 1);
          }}
        />
      )}
    </div>
  );
}

function OvertimeForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [employeeId, setEmployeeId] = useState("");
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");

  const scopeIds = getScopeEmployeeIds(user);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createOvertimeAssignment(user, {
      employeeId,
      date,
      startTime,
      endTime,
      reason,
      notes,
    });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">تكليف عمل إضافي</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">الموظف *</label>
            <select
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="">اختر الموظف</option>
              {dataStore.employees
                .filter((e) => scopeIds.includes(e.id) && e.active && e.id !== user.employeeId)
                .map((emp) => (
                  <option key={emp.id} value={emp.id}>{emp.name}</option>
                ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">التاريخ *</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">من *</label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">إلى *</label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">السبب *</label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">ملاحظات</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-2 border rounded-lg"
              rows={3}
            />
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">إرسال</Button>
          </div>
        </form>
      </div>
    </div>
  );
}