import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getLeaveType,
  getStatusLabel,
  getStatusColor,
  getScopeEmployeeIds,
  getUnreadCount,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface DashboardProps {
  user: User;
  onNavigate: (page: string) => void;
}

export function Dashboard({ user, onNavigate }: DashboardProps) {
  const emp = getEmployee(user.employeeId);
  const scopeIds = getScopeEmployeeIds(user);
  const unreadCount = getUnreadCount(user.id);

  // Get relevant data based on role
  const myLeaves = dataStore.leaveRequests.filter((r) => r.employeeId === user.employeeId);
  const myOvertime = dataStore.overtime.filter((o) => o.employeeId === user.employeeId);
  const myInquiries = dataStore.inquiries.filter((i) => i.employeeId === user.employeeId);
  const myComplaints = dataStore.complaints.filter((c) => c.employeeId === user.employeeId);
  const visibleAnnouncements = dataStore.announcements.filter((a) => {
    if (a.status !== "PUBLISHED") return false;
    if (a.targetType === "ALL") return true;
    if (a.targetType === "DEPARTMENT") return emp?.departmentId === a.targetId;
    if (a.targetType === "SECTION") return emp?.sectionId === a.targetId;
    return emp?.id === a.targetId;
  });

  const scopeLeaves = dataStore.leaveRequests.filter((r) => scopeIds.includes(r.employeeId));
  const scopeOvertime = dataStore.overtime.filter((o) => scopeIds.includes(o.employeeId));
  const pendingApprovals = dataStore.leaveRequests.filter((r) => r.currentApproverId === user.id);
  const pendingOvertime = dataStore.overtime.filter((o) => o.currentApproverId === user.id);

  const isHR = user.role === "HR_OFFICER" || user.role === "HR_MANAGER";
  const isManager = user.role === "SECTION_MANAGER" || user.role === "DEPARTMENT_MANAGER";
  const isGM = user.role === "GENERAL_MANAGER";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">مرحباً، {emp?.name}</h1>
          <p className="text-slate-500 mt-1">{emp?.jobTitle}</p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" onClick={() => onNavigate("notifications")}>
            لديك {unreadCount} إشعارات
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-indigo-50 border-indigo-200">
          <CardContent className="p-4">
            <div className="text-sm text-indigo-600 font-medium">رصيد الإجازة السنوية</div>
            <div className="text-2xl font-bold text-indigo-900 mt-1">{emp?.annualBalance} يوم</div>
          </CardContent>
        </Card>
        <Card className="bg-emerald-50 border-emerald-200">
          <CardContent className="p-4">
            <div className="text-sm text-emerald-600 font-medium">رصيد الإجازة المرضية</div>
            <div className="text-2xl font-bold text-emerald-900 mt-1">{emp?.sickBalance} يوم</div>
          </CardContent>
        </Card>
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="p-4">
            <div className="text-sm text-amber-600 font-medium">طلبات الإجازة</div>
            <div className="text-2xl font-bold text-amber-900 mt-1">{myLeaves.length}</div>
          </CardContent>
        </Card>
        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-4">
            <div className="text-sm text-purple-600 font-medium">تكليفات العمل الإضافي</div>
            <div className="text-2xl font-bold text-purple-900 mt-1">{myOvertime.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3">
        <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => onNavigate("leave")}>
          طلب إجازة
        </Button>
        <Button variant="outline" onClick={() => onNavigate("inquiries")}>
          استفسار جديد
        </Button>
        <Button variant="outline" onClick={() => onNavigate("complaints")}>
          شكوى جديدة
        </Button>
        {isManager && (
          <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => onNavigate("overtime")}>
            تكليف موظف بالعمل الإضافي
          </Button>
        )}
        {isHR && (
          <>
            <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => onNavigate("overtime")}>
              تكليف إضافي
            </Button>
            <Button className="bg-purple-600 hover:bg-purple-700" onClick={() => onNavigate("announcements")}>
              إعلان جديد
            </Button>
            <Button className="bg-amber-600 hover:bg-amber-700" onClick={() => onNavigate("summons")}>
              استدعاء موظف
            </Button>
          </>
        )}
        {isGM && (
          <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => onNavigate("approvals")}>
            الموافقات ({pendingApprovals.length + pendingOvertime.length})
          </Button>
        )}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Leave Requests */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">طلبات الإجازة الأخيرة</CardTitle>
          </CardHeader>
          <CardContent>
            {scopeLeaves.length === 0 ? (
              <p className="text-slate-500 text-sm">لا توجد طلبات إجازة</p>
            ) : (
              <div className="space-y-3">
                {scopeLeaves.slice(0, 5).map((request) => {
                  const requestEmp = getEmployee(request.employeeId);
                  const leaveType = getLeaveType(request.leaveTypeId);
                  return (
                    <div key={request.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div>
                        <div className="text-sm font-medium">{requestEmp?.name}</div>
                        <div className="text-xs text-slate-500">{leaveType?.name}</div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(request.status)}`}>
                        {getStatusLabel(request.status)}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Overtime */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">تكليفات العمل الإضافي</CardTitle>
          </CardHeader>
          <CardContent>
            {scopeOvertime.length === 0 ? (
              <p className="text-slate-500 text-sm">لا توجد تكليفات</p>
            ) : (
              <div className="space-y-3">
                {scopeOvertime.slice(0, 5).map((assignment) => {
                  const assignEmp = getEmployee(assignment.employeeId);
                  return (
                    <div key={assignment.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div>
                        <div className="text-sm font-medium">{assignEmp?.name}</div>
                        <div className="text-xs text-slate-500">{assignment.date} - {assignment.hours} ساعات</div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(assignment.status)}`}>
                        {getStatusLabel(assignment.status)}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Announcements */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">الإعلانات</CardTitle>
          </CardHeader>
          <CardContent>
            {visibleAnnouncements.length === 0 ? (
              <p className="text-slate-500 text-sm">لا توجد إعلانات</p>
            ) : (
              <div className="space-y-3">
                {visibleAnnouncements.slice(0, 5).map((ann) => (
                  <div key={ann.id} className="p-3 bg-slate-50 rounded-lg">
                    <div className="text-sm font-medium">{ann.title}</div>
                    <div className="text-xs text-slate-500 mt-1">{ann.message}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pending Approvals for managers/HR */}
        {(isManager || isHR || isGM) && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">بانتظار الموافقة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingApprovals.length === 0 && pendingOvertime.length === 0 ? (
                  <p className="text-slate-500 text-sm">لا توجد طلبات بانتظار موافقتك</p>
                ) : (
                  <>
                    {pendingApprovals.map((request) => {
                      const requestEmp = getEmployee(request.employeeId);
                      return (
                        <div key={request.id} className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                          <div>
                            <div className="text-sm font-medium">إجازة: {requestEmp?.name}</div>
                            <div className="text-xs text-slate-500">{request.number}</div>
                          </div>
                          <Button size="sm" variant="outline" onClick={() => onNavigate("approvals")}>
                            مراجعة
                          </Button>
                        </div>
                      );
                    })}
                    {pendingOvertime.map((assignment) => {
                      const assignEmp = getEmployee(assignment.employeeId);
                      return (
                        <div key={assignment.id} className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                          <div>
                            <div className="text-sm font-medium">إضافي: {assignEmp?.name}</div>
                            <div className="text-xs text-slate-500">{assignment.number}</div>
                          </div>
                          <Button size="sm" variant="outline" onClick={() => onNavigate("approvals")}>
                            مراجعة
                          </Button>
                        </div>
                      );
                    })}
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}