import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getStatusLabel,
  getStatusColor,
  canViewAllComplaints,
  createComplaint,
  updateComplaintStatus,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface ComplaintsProps {
  user: User;
}

export function Complaints({ user }: ComplaintsProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");

  const canViewAll = canViewAllComplaints(user.role);
  const visibleComplaints = canViewAll
    ? dataStore.complaints
    : dataStore.complaints.filter((c) => c.employeeId === user.employeeId);

  const handleStatusChange = (complaintId: string, status: "IN_REVIEW" | "RESPONDED" | "CLOSED", response?: string) => {
    const result = updateComplaintStatus(user, complaintId, status, response);
    if (!result.success) setError(result.message);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الشكاوى</h1>
          <p className="text-slate-500 mt-1">إدارة شكاوى الموظفين</p>
        </div>
        <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
          شكوى جديدة
        </Button>
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">الشكاوى ({visibleComplaints.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {visibleComplaints.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد شكاوى</p>
          ) : (
            <div className="space-y-4">
              {visibleComplaints.map((comp) => {
                const emp = getEmployee(comp.employeeId);
                return (
                  <div key={comp.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{comp.number}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(comp.status)}`}>
                        {getStatusLabel(comp.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div>الموظف: {emp?.name}</div>
                      <div>الفئة: {comp.category}</div>
                      <div>الموضوع: {comp.subject}</div>
                      <div className="mt-2">{comp.description}</div>
                      {comp.response && (
                        <div className="mt-2 p-2 bg-emerald-50 rounded text-emerald-700">
                          <strong>الرد:</strong> {comp.response}
                        </div>
                      )}
                    </div>
                    {canViewAll && (
                      <div className="flex gap-2 mt-3">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleStatusChange(comp.id, "IN_REVIEW")}
                        >
                          قيد المراجعة
                        </Button>
                        <Button
                          size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => {
                            const response = prompt("أدخل الرد:");
                            if (response) handleStatusChange(comp.id, "RESPONDED", response);
                          }}
                        >
                          رد
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleStatusChange(comp.id, "CLOSED")}
                        >
                          إغلاق
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {showForm && (
        <ComplaintForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => setShowForm(false)}
        />
      )}
    </div>
  );
}

function ComplaintForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [category, setCategory] = useState("");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [confidential, setConfidential] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createComplaint(user, { category, subject, description, confidential });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">شكوى جديدة</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">الفئة *</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="">اختر الفئة</option>
              <option value="الراتب">الراتب</option>
              <option value="بيئة العمل">بيئة العمل</option>
              <option value="العلاقات">العلاقات</option>
              <option value="التمييز">التمييز</option>
              <option value="التحرش">التحرش</option>
              <option value="أخرى">أخرى</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الموضوع *</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الوصف *</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2 border rounded-lg"
              rows={4}
              required
            />
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={confidential}
              onChange={(e) => setConfidential(e.target.checked)}
              className="w-4 h-4"
            />
            <label className="text-sm">سرية</label>
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">إرسال</Button>
          </div>
        </form>
      </div>
    </div>
  );
}