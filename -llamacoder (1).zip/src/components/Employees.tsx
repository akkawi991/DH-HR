import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { dataStore, getEmployee, getOrgUnit, getScopeEmployeeIds } from "@/lib/data";
import type { User } from "@/lib/data";

interface EmployeesProps {
  user: User;
}

export function Employees({ user }: EmployeesProps) {
  const scopeIds = getScopeEmployeeIds(user);
  const visibleEmployees = dataStore.employees.filter((e) => scopeIds.includes(e.id) && e.active);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">الموظفون</h1>
        <p className="text-slate-500 mt-1">إدارة بيانات الموظفين</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">الموظفون ({visibleEmployees.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-right p-3">الرقم الوظيفي</th>
                  <th className="text-right p-3">الاسم</th>
                  <th className="text-right p-3">المسمى الوظيفي</th>
                  <th className="text-right p-3">الإدارة</th>
                  <th className="text-right p-3">القسم</th>
                  <th className="text-right p-3">المدير المباشر</th>
                  <th className="text-right p-3">رصيد الإجازات</th>
                </tr>
              </thead>
              <tbody>
                {visibleEmployees.map((emp) => {
                  const dept = getOrgUnit(emp.departmentId);
                  const section = getOrgUnit(emp.sectionId);
                  const manager = getEmployee(emp.managerId);
                  return (
                    <tr key={emp.id} className="border-b border-slate-100">
                      <td className="p-3">{emp.employeeNumber}</td>
                      <td className="p-3 font-medium">{emp.name}</td>
                      <td className="p-3">{emp.jobTitle}</td>
                      <td className="p-3">{dept?.name || "-"}</td>
                      <td className="p-3">{section?.name || "-"}</td>
                      <td className="p-3">{manager?.name || "-"}</td>
                      <td className="p-3">
                        <span className="text-xs text-slate-500">
                          سنوية: {emp.annualBalance} | مرضية: {emp.sickBalance}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}