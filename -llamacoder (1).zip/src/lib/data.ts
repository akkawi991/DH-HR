export type Role =
  | "EMPLOYEE"
  | "SECTION_MANAGER"
  | "DEPARTMENT_MANAGER"
  | "HR_OFFICER"
  | "HR_MANAGER"
  | "GENERAL_MANAGER";

export interface User {
  id: string;
  username: string;
  password: string;
  email: string;
  role: Role;
  employeeId: string;
  active: boolean;
  lastLogin?: string;
  createdAt: string;
}

export interface Employee {
  id: string;
  employeeNumber: string;
  name: string;
  jobTitle: string;
  departmentId: string | null;
  sectionId: string | null;
  managerId: string | null;
  annualBalance: number;
  sickBalance: number;
  active: boolean;
}

export interface OrgUnit {
  id: string;
  name: string;
  code: string;
  type: "COMPANY" | "DEPARTMENT" | "SECTION";
  parentId: string | null;
  managerId: string | null;
  active: boolean;
}

export interface LeaveType {
  id: string;
  name: string;
  code: string;
  unitType: "DAYS" | "HOURS";
  requiresAttachment: boolean;
  affectsBalance: boolean;
  active: boolean;
  description: string;
}

export type LeaveStatus =
  | "DRAFT"
  | "SUBMITTED"
  | "PENDING_MANAGER"
  | "MANAGER_APPROVED"
  | "PENDING_HR_OFFICER"
  | "HR_OFFICER_APPROVED"
  | "PENDING_HR_MANAGER"
  | "HR_APPROVED"
  | "PENDING_GM"
  | "GM_APPROVED"
  | "GM_REJECTED"
  | "REJECTED"
  | "CANCELLED"
  | "WORKFLOW_ERROR";

export interface WorkflowStep {
  id: string;
  stepOrder: number;
  stepType: "MANAGER" | "HR_OFFICER" | "HR_MANAGER" | "GENERAL_MANAGER";
  approverUserId: string | null;
  approverEmployeeId: string | null;
  approverRoleSnapshot: string;
  orgUnitSnapshot: string;
  status: "PENDING" | "APPROVED" | "REJECTED" | "SKIPPED";
  required: boolean;
  actionedAt?: string;
  comment?: string;
}

export interface WorkflowInstance {
  id: string;
  requestType: string;
  requestId: string;
  requestOwnerEmployeeId: string;
  submittedByUserId: string;
  steps: WorkflowStep[];
  currentStepIndex: number;
  status: string;
  createdAt: string;
  updatedAt: string;
}

export interface WorkflowHistory {
  id: string;
  requestType: string;
  requestId: string;
  fromStatus: string;
  toStatus: string;
  action: string;
  performedBy: string;
  comment?: string;
  timestamp: string;
}

export interface LeaveRequest {
  id: string;
  number: string;
  employeeId: string;
  submittedBy: string;
  leaveTypeId: string;
  startDate: string;
  endDate: string;
  startTime?: string;
  endTime?: string;
  days: number;
  hours: number;
  reason: string;
  status: LeaveStatus;
  currentApproverId: string | null;
  workflowInstanceId: string | null;
  hrNotes?: string;
  finalNotes?: string;
  attachments: Attachment[];
  history: WorkflowHistory[];
  createdAt: string;
  updatedAt: string;
}

export interface OvertimeAssignment {
  id: string;
  number: string;
  employeeId: string;
  assignedBy: string;
  date: string;
  startTime: string;
  endTime: string;
  hours: number;
  reason: string;
  notes?: string;
  status: "DRAFT" | "SUBMITTED" | "PENDING_HR" | "HR_REVIEWED" | "PENDING_GM" | "APPROVED" | "REJECTED" | "CANCELLED" | "WORKFLOW_ERROR";
  currentApproverId: string | null;
  workflowInstanceId: string | null;
  attachments: Attachment[];
  history: WorkflowHistory[];
  createdAt: string;
  updatedAt: string;
}

export interface Inquiry {
  id: string;
  number: string;
  employeeId: string;
  category: string;
  subject: string;
  question: string;
  status: "NEW" | "IN_PROGRESS" | "ANSWERED" | "CLOSED";
  assignedTo?: string;
  response?: string;
  internalNotes?: string;
  attachments: Attachment[];
  createdAt: string;
  resolvedAt?: string;
}

export interface Complaint {
  id: string;
  number: string;
  employeeId: string;
  category: string;
  subject: string;
  description: string;
  confidential: boolean;
  status: "NEW" | "IN_REVIEW" | "RESPONDED" | "CLOSED";
  assignedTo?: string;
  response?: string;
  internalNotes?: string;
  attachments: Attachment[];
  createdAt: string;
  closedAt?: string;
}

export interface Announcement {
  id: string;
  title: string;
  type: "ANNOUNCEMENT" | "CIRCULAR";
  message: string;
  targetType: "ALL" | "DEPARTMENT" | "SECTION" | "EMPLOYEE";
  targetId?: string;
  createdBy: string;
  publishDate: string;
  expiryDate: string;
  status: "DRAFT" | "PUBLISHED" | "EXPIRED";
  attachments: Attachment[];
  createdAt: string;
}

export interface Summons {
  id: string;
  number: string;
  employeeId: string;
  subject: string;
  date: string;
  time: string;
  location: string;
  message: string;
  createdBy: string;
  status: "DRAFT" | "ISSUED" | "ACKNOWLEDGED";
  attachments: Attachment[];
  createdAt: string;
}

export interface Attachment {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
  uploadedBy: string;
  uploadedAt: string;
}

export interface Notification {
  id: string;
  recipientId: string;
  title: string;
  message: string;
  type: string;
  referenceType?: string;
  referenceId?: string;
  read: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  action: string;
  entityType: string;
  entityId: string;
  oldValue?: string;
  newValue?: string;
  timestamp: string;
}

// Seed data
const employees: Employee[] = [
  { id: "emp1", employeeNumber: "1001", name: "أحمد محمد", jobTitle: "موظف", departmentId: "dept1", sectionId: "sec1", managerId: "emp4", annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp2", employeeNumber: "1002", name: "سارة أحمد", jobTitle: "موظف", departmentId: "dept1", sectionId: "sec1", managerId: "emp4", annualBalance: 25, sickBalance: 12, active: true },
  { id: "emp3", employeeNumber: "1003", name: "محمد علي", jobTitle: "موظف", departmentId: "dept1", sectionId: "sec2", managerId: "emp5", annualBalance: 28, sickBalance: 10, active: true },
  { id: "emp4", employeeNumber: "2001", name: "خالد عبدالله", jobTitle: "مدير قسم", departmentId: "dept1", sectionId: "sec1", managerId: "emp7", annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp5", employeeNumber: "2002", name: "نورة سعد", jobTitle: "مدير قسم", departmentId: "dept1", sectionId: "sec2", managerId: "emp7", annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp6", employeeNumber: "2003", name: "فهد العتيبي", jobTitle: "موظف", departmentId: "dept2", sectionId: "sec3", managerId: "emp8", annualBalance: 22, sickBalance: 8, active: true },
  { id: "emp7", employeeNumber: "3001", name: "عبدالرحمن الحربي", jobTitle: "مدير إدارة", departmentId: "dept1", sectionId: null, managerId: "emp10", annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp8", employeeNumber: "3002", name: "منى القحطاني", jobTitle: "مدير إدارة", departmentId: "dept2", sectionId: null, managerId: "emp10", annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp9", employeeNumber: "4001", name: "ريم الشمري", jobTitle: "موظف موارد بشرية", departmentId: "dept3", sectionId: "sec4", managerId: "emp11", annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp10", employeeNumber: "5001", name: "سلطان المطيري", jobTitle: "المدير العام", departmentId: "dept4", sectionId: null, managerId: null, annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp11", employeeNumber: "5002", name: "هند الدوسري", jobTitle: "مدير موارد بشرية", departmentId: "dept3", sectionId: null, managerId: "emp10", annualBalance: 30, sickBalance: 15, active: true },
  { id: "emp12", employeeNumber: "4002", name: "ماجد العنزي", jobTitle: "موظف موارد بشرية", departmentId: "dept3", sectionId: "sec4", managerId: "emp11", annualBalance: 30, sickBalance: 15, active: true },
];

const users: User[] = [
  { id: "user1", username: "emp1", password: "123456", email: "ahmed@dh.com", role: "EMPLOYEE", employeeId: "emp1", active: true, createdAt: "2026-01-01" },
  { id: "user2", username: "emp2", password: "123456", email: "sara@dh.com", role: "EMPLOYEE", employeeId: "emp2", active: true, createdAt: "2026-01-01" },
  { id: "user3", username: "emp3", password: "123456", email: "mohammed@dh.com", role: "EMPLOYEE", employeeId: "emp3", active: true, createdAt: "2026-01-01" },
  { id: "user4", username: "sm1", password: "123456", email: "khaled@dh.com", role: "SECTION_MANAGER", employeeId: "emp4", active: true, createdAt: "2026-01-01" },
  { id: "user5", username: "sm2", password: "123456", email: "noura@dh.com", role: "SECTION_MANAGER", employeeId: "emp5", active: true, createdAt: "2026-01-01" },
  { id: "user6", username: "dm1", password: "123456", email: "abdulrahman@dh.com", role: "DEPARTMENT_MANAGER", employeeId: "emp7", active: true, createdAt: "2026-01-01" },
  { id: "user7", username: "dm2", password: "123456", email: "mona@dh.com", role: "DEPARTMENT_MANAGER", employeeId: "emp8", active: true, createdAt: "2026-01-01" },
  { id: "user8", username: "hro1", password: "123456", email: "reem@dh.com", role: "HR_OFFICER", employeeId: "emp9", active: true, createdAt: "2026-01-01" },
  { id: "user9", username: "hrm", password: "123456", email: "hind@dh.com", role: "HR_MANAGER", employeeId: "emp11", active: true, createdAt: "2026-01-01" },
  { id: "user10", username: "gm", password: "123456", email: "sultan@dh.com", role: "GENERAL_MANAGER", employeeId: "emp10", active: true, createdAt: "2026-01-01" },
  { id: "user11", username: "hro2", password: "123456", email: "majed@dh.com", role: "HR_OFFICER", employeeId: "emp12", active: true, createdAt: "2026-01-01" },
];

const orgUnits: OrgUnit[] = [
  { id: "company1", name: "شركة DH", code: "DH", type: "COMPANY", parentId: null, managerId: "emp10", active: true },
  { id: "dept1", name: "إدارة المبيعات", code: "SALES", type: "DEPARTMENT", parentId: "company1", managerId: "emp7", active: true },
  { id: "dept2", name: "إدارة الإنتاج", code: "PROD", type: "DEPARTMENT", parentId: "company1", managerId: "emp8", active: true },
  { id: "dept3", name: "إدارة الموارد البشرية", code: "HR", type: "DEPARTMENT", parentId: "company1", managerId: "emp11", active: true },
  { id: "dept4", name: "الإدارة العامة", code: "GM", type: "DEPARTMENT", parentId: "company1", managerId: "emp10", active: true },
  { id: "sec1", name: "قسم الصالات", code: "HALLS", type: "SECTION", parentId: "dept1", managerId: "emp4", active: true },
  { id: "sec2", name: "قسم التوصيل", code: "DELIVERY", type: "SECTION", parentId: "dept1", managerId: "emp5", active: true },
  { id: "sec3", name: "قسم المعمل", code: "LAB", type: "SECTION", parentId: "dept2", managerId: "emp8", active: true },
  { id: "sec4", name: "قسم شؤون الموظفين", code: "AFFAIRS", type: "SECTION", parentId: "dept3", managerId: "emp11", active: true },
];

const leaveTypes: LeaveType[] = [
  { id: "lt1", name: "إجازة إدارية", code: "ADMIN", unitType: "DAYS", requiresAttachment: false, affectsBalance: true, active: true, description: "إجازة إدارية" },
  { id: "lt2", name: "إجازة بلا راتب", code: "UNPAID", unitType: "DAYS", requiresAttachment: false, affectsBalance: true, active: true, description: "إجازة بدون راتب" },
  { id: "lt3", name: "إجازة مرضية", code: "SICK", unitType: "DAYS", requiresAttachment: true, affectsBalance: true, active: true, description: "إجازة مرضية" },
  { id: "lt4", name: "إجازة زواج", code: "MARRIAGE", unitType: "DAYS", requiresAttachment: true, affectsBalance: true, active: true, description: "إجازة زواج" },
  { id: "lt5", name: "إجازة وفاة", code: "DEATH", unitType: "DAYS", requiresAttachment: true, affectsBalance: true, active: true, description: "إجازة وفاة" },
  { id: "lt6", name: "إجازة ولادة", code: "BIRTH", unitType: "DAYS", requiresAttachment: true, affectsBalance: true, active: true, description: "إجازة ولادة" },
  { id: "lt7", name: "إجازة ساعية", code: "HOURLY", unitType: "HOURS", requiresAttachment: false, affectsBalance: true, active: true, description: "إجازة بالساعات" },
  { id: "lt8", name: "أخرى", code: "OTHER", unitType: "DAYS", requiresAttachment: false, affectsBalance: true, active: true, description: "إجازة أخرى" },
];

// State
let currentUser: User | null = null;
let leaveRequests: LeaveRequest[] = [];
let overtimeAssignments: OvertimeAssignment[] = [];
let inquiries: Inquiry[] = [];
let complaints: Complaint[] = [];
let announcements: Announcement[] = [];
let summonsList: Summons[] = [];
let notifications: Notification[] = [];
let auditLogs: AuditLog[] = [];
let workflowInstances: WorkflowInstance[] = [];
let idCounter = 1;

// Helper functions
export function getEmployee(id: string | null): Employee | undefined {
  return employees.find((e) => e.id === id);
}

export function getUser(id: string): User | undefined {
  return users.find((u) => u.id === id);
}

export function getOrgUnit(id: string | null): OrgUnit | undefined {
  return orgUnits.find((o) => o.id === id);
}

export function getLeaveType(id: string): LeaveType | undefined {
  return leaveTypes.find((lt) => lt.id === id);
}

export function getRoleLabel(role: Role): string {
  const labels: Record<Role, string> = {
    EMPLOYEE: "موظف",
    SECTION_MANAGER: "مدير قسم",
    DEPARTMENT_MANAGER: "مدير إدارة",
    HR_OFFICER: "موظف موارد بشرية",
    HR_MANAGER: "مدير موارد بشرية",
    GENERAL_MANAGER: "مدير عام",
  };
  return labels[role];
}

export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    DRAFT: "مسودة",
    SUBMITTED: "مرسل",
    PENDING_MANAGER: "بانتظار موافقة المدير المباشر",
    MANAGER_APPROVED: "تمت موافقة المدير المباشر",
    PENDING_HR_OFFICER: "بانتظار موافقة موظف الموارد البشرية",
    HR_OFFICER_APPROVED: "تمت موافقة موظف الموارد البشرية",
    PENDING_HR_MANAGER: "بانتظار اعتماد مدير الموارد البشرية",
    HR_APPROVED: "معتمد من الموارد البشرية",
    PENDING_GM: "بانتظار اعتماد المدير العام",
    GM_APPROVED: "معتمد من المدير العام",
    GM_REJECTED: "مرفوض من المدير العام",
    REJECTED: "مرفوض",
    CANCELLED: "ملغى",
    WORKFLOW_ERROR: "خطأ في مسار الموافقة",
    NEW: "جديد",
    IN_PROGRESS: "قيد المعالجة",
    ANSWERED: "تم الرد",
    CLOSED: "مغلق",
    IN_REVIEW: "قيد المراجعة",
    RESPONDED: "تم الرد",
    PUBLISHED: "منشور",
    EXPIRED: "منتهي",
    ISSUED: "صادر",
    ACKNOWLEDGED: "تم الاستلام",
    APPROVED: "موافق عليه",
    PENDING_HR: "بانتظار مراجعة الموارد البشرية",
    HR_REVIEWED: "تمت مراجعة الموارد البشرية",
  };
  return labels[status] || status;
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    DRAFT: "bg-slate-100 text-slate-700",
    SUBMITTED: "bg-blue-100 text-blue-700",
    PENDING_MANAGER: "bg-amber-100 text-amber-700",
    MANAGER_APPROVED: "bg-emerald-100 text-emerald-700",
    PENDING_HR_OFFICER: "bg-amber-100 text-amber-700",
    HR_OFFICER_APPROVED: "bg-emerald-100 text-emerald-700",
    PENDING_HR_MANAGER: "bg-amber-100 text-amber-700",
    HR_APPROVED: "bg-emerald-100 text-emerald-700",
    PENDING_GM: "bg-purple-100 text-purple-700",
    GM_APPROVED: "bg-emerald-100 text-emerald-700",
    GM_REJECTED: "bg-red-100 text-red-700",
    REJECTED: "bg-red-100 text-red-700",
    CANCELLED: "bg-slate-100 text-slate-700",
    WORKFLOW_ERROR: "bg-red-100 text-red-700",
    NEW: "bg-blue-100 text-blue-700",
    IN_PROGRESS: "bg-amber-100 text-amber-700",
    ANSWERED: "bg-emerald-100 text-emerald-700",
    CLOSED: "bg-slate-100 text-slate-700",
    IN_REVIEW: "bg-amber-100 text-amber-700",
    RESPONDED: "bg-emerald-100 text-emerald-700",
    PUBLISHED: "bg-emerald-100 text-emerald-700",
    EXPIRED: "bg-slate-100 text-slate-700",
    ISSUED: "bg-blue-100 text-blue-700",
    ACKNOWLEDGED: "bg-emerald-100 text-emerald-700",
    APPROVED: "bg-emerald-100 text-emerald-700",
    PENDING_HR: "bg-amber-100 text-amber-700",
    HR_REVIEWED: "bg-emerald-100 text-emerald-700",
  };
  return colors[status] || "bg-slate-100 text-slate-700";
}

// Auth functions
export function login(username: string, password: string): User | null {
  const user = users.find((u) => u.username === username && u.password === password && u.active);
  if (user) {
    currentUser = user;
    user.lastLogin = new Date().toISOString();
    addAuditLog(user.id, "LOGIN", "USER", user.id);
    return user;
  }
  return null;
}

export function logout(): void {
  if (currentUser) {
    addAuditLog(currentUser.id, "LOGOUT", "USER", currentUser.id);
  }
  currentUser = null;
}

export function currentUserInfo(): User | null {
  return currentUser;
}

// Scope functions
export function getScopeEmployeeIds(user: User): string[] {
  const emp = getEmployee(user.employeeId);
  if (!emp) return [];

  switch (user.role) {
    case "GENERAL_MANAGER":
    case "HR_MANAGER":
    case "HR_OFFICER":
      return employees.filter((e) => e.active).map((e) => e.id);
    case "DEPARTMENT_MANAGER": {
      const deptId = emp.departmentId;
      const deptEmployees = employees.filter((e) => e.departmentId === deptId && e.active);
      return deptEmployees.map((e) => e.id);
    }
    case "SECTION_MANAGER": {
      const sectionId = emp.sectionId;
      const sectionEmployees = employees.filter((e) => e.sectionId === sectionId && e.active);
      return sectionEmployees.map((e) => e.id);
    }
    default:
      return [emp.id];
  }
}

export function canCreateLeaveForOthers(role: Role): boolean {
  return ["SECTION_MANAGER", "DEPARTMENT_MANAGER", "HR_OFFICER", "HR_MANAGER"].includes(role);
}

export function canCreateOvertime(role: Role): boolean {
  return ["SECTION_MANAGER", "DEPARTMENT_MANAGER", "HR_OFFICER", "HR_MANAGER"].includes(role);
}

export function canViewAllInquiries(role: Role): boolean {
  return ["HR_OFFICER", "HR_MANAGER"].includes(role);
}

export function canViewAllComplaints(role: Role): boolean {
  return ["HR_OFFICER", "HR_MANAGER"].includes(role);
}

export function canCreateAnnouncements(role: Role): boolean {
  return ["HR_OFFICER", "HR_MANAGER"].includes(role);
}

export function canCreateSummons(role: Role): boolean {
  return ["HR_OFFICER", "HR_MANAGER"].includes(role);
}

export function canManageUsers(role: Role): boolean {
  return role === "HR_MANAGER";
}

export function canManageOrg(role: Role): boolean {
  return role === "HR_MANAGER";
}

// Dynamic Workflow Engine
function resolveManagementChain(employeeId: string): Employee[] {
  const chain: Employee[] = [];
  const visited = new Set<string>();
  let current = getEmployee(employeeId);
  
  while (current && current.managerId && !visited.has(current.managerId)) {
    visited.add(current.managerId);
    const manager = getEmployee(current.managerId);
    if (manager) {
      chain.push(manager);
      current = manager;
    } else {
      break;
    }
  }
  
  return chain;
}

function getHROfficers(): Employee[] {
  return employees.filter((e) => {
    const user = users.find((u) => u.employeeId === e.id);
    return user?.role === "HR_OFFICER" && e.active;
  });
}

function getHRManager(): Employee | undefined {
  return getEmployee("emp11");
}

function getGeneralManager(): Employee | undefined {
  return getEmployee("emp10");
}

export function resolveWorkflow(requestType: string, requestOwnerEmployeeId: string, submittedByUserId: string): WorkflowInstance {
  const steps: WorkflowStep[] = [];
  let stepOrder = 1;
  
  // Resolve management chain
  const managementChain = resolveManagementChain(requestOwnerEmployeeId);
  
  // Add management approval steps
  for (const manager of managementChain) {
    const managerUser = users.find((u) => u.employeeId === manager.id);
    if (managerUser) {
      // Skip if the submitter is the same as the approver (self-approval prevention)
      if (managerUser.id === submittedByUserId) {
        continue;
      }
      
      steps.push({
        id: `step-${idCounter++}`,
        stepOrder: stepOrder++,
        stepType: "MANAGER",
        approverUserId: managerUser.id,
        approverEmployeeId: manager.id,
        approverRoleSnapshot: managerUser.role,
        orgUnitSnapshot: manager.departmentId || "",
        status: "PENDING",
        required: true,
      });
    }
  }
  
  // Add HR Officer step for leave requests
  if (requestType === "LEAVE") {
    const hrOfficers = getHROfficers();
    if (hrOfficers.length > 0) {
      const hrOfficerUser = users.find((u) => u.employeeId === hrOfficers[0].id);
      if (hrOfficerUser && hrOfficerUser.id !== submittedByUserId) {
        steps.push({
          id: `step-${idCounter++}`,
          stepOrder: stepOrder++,
          stepType: "HR_OFFICER",
          approverUserId: hrOfficerUser.id,
          approverEmployeeId: hrOfficers[0].id,
          approverRoleSnapshot: "HR_OFFICER",
          orgUnitSnapshot: "HR",
          status: "PENDING",
          required: true,
        });
      }
    }
  }
  
  // Add HR Manager step
  const hrManager = getHRManager();
  if (hrManager) {
    const hrManagerUser = users.find((u) => u.employeeId === hrManager.id);
    if (hrManagerUser && hrManagerUser.id !== submittedByUserId) {
      steps.push({
        id: `step-${idCounter++}`,
        stepOrder: stepOrder++,
        stepType: "HR_MANAGER",
        approverUserId: hrManagerUser.id,
        approverEmployeeId: hrManager.id,
        approverRoleSnapshot: "HR_MANAGER",
        orgUnitSnapshot: "HR",
        status: "PENDING",
        required: true,
      });
    }
  }
  
  // Add GM step for overtime
  if (requestType === "OVERTIME") {
    const gm = getGeneralManager();
    if (gm) {
      const gmUser = users.find((u) => u.employeeId === gm.id);
      if (gmUser && gmUser.id !== submittedByUserId) {
        steps.push({
          id: `step-${idCounter++}`,
          stepOrder: stepOrder++,
          stepType: "GENERAL_MANAGER",
          approverUserId: gmUser.id,
          approverEmployeeId: gm.id,
          approverRoleSnapshot: "GENERAL_MANAGER",
          orgUnitSnapshot: "GM",
          status: "PENDING",
          required: true,
        });
      }
    }
  }
  
  // If no steps were created, set workflow error
  if (steps.length === 0) {
    return {
      id: `wf-${idCounter++}`,
      requestType,
      requestId: "",
      requestOwnerEmployeeId,
      submittedByUserId,
      steps: [],
      currentStepIndex: -1,
      status: "WORKFLOW_ERROR",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  }
  
  const workflow: WorkflowInstance = {
    id: `wf-${idCounter++}`,
    requestType,
    requestId: "",
    requestOwnerEmployeeId,
    submittedByUserId,
    steps,
    currentStepIndex: 0,
    status: "PENDING",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  
  workflowInstances.push(workflow);
  return workflow;
}

export function getWorkflowInstance(id: string): WorkflowInstance | undefined {
  return workflowInstances.find((w) => w.id === id);
}

export function getWorkflowAllowedActions(user: User, workflow: WorkflowInstance): string[] {
  if (workflow.status === "WORKFLOW_ERROR") return [];
  if (workflow.currentStepIndex < 0 || workflow.currentStepIndex >= workflow.steps.length) return [];
  
  const currentStep = workflow.steps[workflow.currentStepIndex];
  if (currentStep.approverUserId !== user.id) return [];
  
  const actions: string[] = ["APPROVE", "REJECT"];
  
  // HR Manager can also forward to GM
  if (currentStep.stepType === "HR_MANAGER") {
    actions.push("FORWARD");
  }
  
  return actions;
}

export function performWorkflowAction(user: User, workflow: WorkflowInstance, action: string, comment?: string): { success: boolean; message: string } {
  if (workflow.status === "WORKFLOW_ERROR") {
    return { success: false, message: "تعذر تحديد مسار الموافقة لهذا الطلب. يرجى مراجعة الهيكل التنظيمي." };
  }
  
  if (workflow.currentStepIndex < 0 || workflow.currentStepIndex >= workflow.steps.length) {
    return { success: false, message: "خطأ في مسار الموافقة" };
  }
  
  const currentStep = workflow.steps[workflow.currentStepIndex];
  if (currentStep.approverUserId !== user.id) {
    return { success: false, message: "غير مصرح لك بتنفيذ هذا الإجراء" };
  }
  
  if (action === "REJECT" && !comment) {
    return { success: false, message: "سبب الرفض مطلوب" };
  }
  
  if (action === "FORWARD" && !comment) {
    return { success: false, message: "سبب التحويل مطلوب" };
  }
  
  const fromStatus = workflow.status;
  
  if (action === "APPROVE") {
    currentStep.status = "APPROVED";
    currentStep.actionedAt = new Date().toISOString();
    currentStep.comment = comment;
    
    // Move to next step
    workflow.currentStepIndex++;
    
    if (workflow.currentStepIndex >= workflow.steps.length) {
      workflow.status = "APPROVED";
    } else {
      workflow.status = "PENDING";
    }
  } else if (action === "REJECT") {
    currentStep.status = "REJECTED";
    currentStep.actionedAt = new Date().toISOString();
    currentStep.comment = comment;
    workflow.status = "REJECTED";
  } else if (action === "FORWARD") {
    currentStep.status = "APPROVED";
    currentStep.actionedAt = new Date().toISOString();
    currentStep.comment = comment;
    
    // Add GM step if not exists
    const gm = getGeneralManager();
    if (gm) {
      const gmUser = users.find((u) => u.employeeId === gm.id);
      if (gmUser) {
        // Remove any existing GM steps
        workflow.steps = workflow.steps.filter((s) => s.stepType !== "GENERAL_MANAGER");
        
        workflow.steps.push({
          id: `step-${idCounter++}`,
          stepOrder: workflow.steps.length + 1,
          stepType: "GENERAL_MANAGER",
          approverUserId: gmUser.id,
          approverEmployeeId: gm.id,
          approverRoleSnapshot: "GENERAL_MANAGER",
          orgUnitSnapshot: "GM",
          status: "PENDING",
          required: true,
        });
        
        workflow.currentStepIndex = workflow.steps.length - 1;
        workflow.status = "PENDING_GM";
      }
    }
  }
  
  workflow.updatedAt = new Date().toISOString();
  
  // Add audit log
  addAuditLog(user.id, action, "WORKFLOW", workflow.id, fromStatus, workflow.status);
  
  return { success: true, message: "تم تنفيذ الإجراء بنجاح" };
}

// Leave request functions
export function createLeaveRequest(user: User, data: {
  employeeId: string;
  leaveTypeId: string;
  startDate: string;
  endDate: string;
  startTime?: string;
  endTime?: string;
  reason: string;
  attachments?: Attachment[];
}): { success: boolean; message: string; request?: LeaveRequest } {
  const leaveType = getLeaveType(data.leaveTypeId);
  if (!leaveType) return { success: false, message: "يرجى اختيار نوع الإجازة" };

  // Validate dates
  if (leaveType.unitType === "DAYS") {
    if (!data.startDate || !data.endDate) return { success: false, message: "يرجى إدخال تاريخ البداية والنهاية" };
    if (new Date(data.endDate) < new Date(data.startDate)) {
      return { success: false, message: "تاريخ نهاية الإجازة يجب أن يكون بعد تاريخ البداية" };
    }
  } else {
    if (!data.startDate || !data.startTime || !data.endTime) {
      return { success: false, message: "يرجى إدخال التاريخ والوقت" };
    }
    if (data.endTime <= data.startTime) {
      return { success: false, message: "وقت النهاية يجب أن يكون بعد وقت البداية" };
    }
  }

  // Check authorization
  const scopeIds = getScopeEmployeeIds(user);
  if (!scopeIds.includes(data.employeeId)) {
    return { success: false, message: "غير مصرح لك بإنشاء طلب لهذا الموظف" };
  }

  // Calculate days/hours
  let days = 0;
  let hours = 0;
  if (leaveType.unitType === "DAYS") {
    const start = new Date(data.startDate);
    const end = new Date(data.endDate);
    days = Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    if (days <= 0) return { success: false, message: "مدة الإجازة يجب أن تكون يوم واحد على الأقل" };
  } else {
    const [sh, sm] = data.startTime!.split(":").map(Number);
    const [eh, em] = data.endTime!.split(":").map(Number);
    hours = (eh + em / 60) - (sh + sm / 60);
    if (hours <= 0) return { success: false, message: "مدة الإجازة يجب أن تكون أكبر من صفر" };
  }

  // Resolve workflow
  const workflow = resolveWorkflow("LEAVE", data.employeeId, user.id);
  
  const request: LeaveRequest = {
    id: `lv-${idCounter++}`,
    number: `LV-2026-${String(idCounter).padStart(4, "0")}`,
    employeeId: data.employeeId,
    submittedBy: user.id,
    leaveTypeId: data.leaveTypeId,
    startDate: data.startDate,
    endDate: data.endDate,
    startTime: data.startTime,
    endTime: data.endTime,
    days,
    hours,
    reason: data.reason,
    status: workflow.status === "WORKFLOW_ERROR" ? "WORKFLOW_ERROR" : "PENDING_MANAGER",
    currentApproverId: workflow.steps[0]?.approverUserId || null,
    workflowInstanceId: workflow.id,
    attachments: data.attachments || [],
    history: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  
  workflow.requestId = request.id;
  leaveRequests.push(request);
  
  // Add workflow history
  addWorkflowHistory(request.id, "LEAVE", "DRAFT", request.status, "SUBMIT", user.id, "تم إنشاء الطلب");
  
  // Add notification for first approver
  if (workflow.steps[0]?.approverUserId) {
    addNotification(workflow.steps[0].approverUserId, "طلب إجازة جديد", `طلب إجازة جديد بانتظار موافقتك`, "LEAVE", request.id);
  }
  
  addAuditLog(user.id, "CREATE", "LEAVE_REQUEST", request.id);
  
  return { success: true, message: "تم إنشاء طلب الإجازة بنجاح", request };
}

export function getLeaveAllowedActions(user: User, request: LeaveRequest): string[] {
  if (!request.workflowInstanceId) return [];
  const workflow = getWorkflowInstance(request.workflowInstanceId);
  if (!workflow) return [];
  return getWorkflowAllowedActions(user, workflow);
}

export function performLeaveAction(user: User, requestId: string, action: string, comment?: string): { success: boolean; message: string } {
  const request = leaveRequests.find((r) => r.id === requestId);
  if (!request) return { success: false, message: "الطلب غير موجود" };
  if (!request.workflowInstanceId) return { success: false, message: "خطأ في مسار الموافقة" };
  
  const workflow = getWorkflowInstance(request.workflowInstanceId);
  if (!workflow) return { success: false, message: "خطأ في مسار الموافقة" };
  
  const result = performWorkflowAction(user, workflow, action, comment);
  if (result.success) {
    // Update request status based on workflow
    if (workflow.status === "APPROVED") {
      request.status = "HR_APPROVED";
    } else if (workflow.status === "REJECTED") {
      request.status = "REJECTED";
    } else if (workflow.status === "PENDING_GM") {
      request.status = "PENDING_GM";
    } else if (workflow.status === "PENDING") {
      const currentStep = workflow.steps[workflow.currentStepIndex];
      if (currentStep?.stepType === "HR_OFFICER") {
        request.status = "PENDING_HR_OFFICER";
      } else if (currentStep?.stepType === "HR_MANAGER") {
        request.status = "PENDING_HR_MANAGER";
      } else {
        request.status = "PENDING_MANAGER";
      }
    }
    
    request.currentApproverId = workflow.steps[workflow.currentStepIndex]?.approverUserId || null;
    request.updatedAt = new Date().toISOString();
    
    // Add workflow history
    addWorkflowHistory(request.id, "LEAVE", request.status, request.status, action, user.id, comment);
    
    // Add notification for next approver
    if (request.currentApproverId) {
      addNotification(request.currentApproverId, "طلب إجازة", `طلب إجازة بانتظار موافقتك`, "LEAVE", request.id);
    }
  }
  
  return result;
}

// Overtime functions
export function createOvertimeAssignment(user: User, data: {
  employeeId: string;
  date: string;
  startTime: string;
  endTime: string;
  reason: string;
  notes?: string;
  attachments?: Attachment[];
}): { success: boolean; message: string; assignment?: OvertimeAssignment } {
  // Check authorization
  if (!canCreateOvertime(user.role)) {
    return { success: false, message: "غير مصرح لك بإنشاء تكليف إضافي" };
  }
  
  // Prevent self-assignment
  if (data.employeeId === user.employeeId) {
    return { success: false, message: "لا يمكنك تكليف نفسك بالعمل الإضافي" };
  }
  
  const scopeIds = getScopeEmployeeIds(user);
  if (!scopeIds.includes(data.employeeId)) {
    return { success: false, message: "غير مصرح لك بإنشاء تكليف لهذا الموظف" };
  }
  
  // Validate times
  if (!data.date || !data.startTime || !data.endTime) {
    return { success: false, message: "يرجى إدخال التاريخ والوقت" };
  }
  if (data.endTime <= data.startTime) {
    return { success: false, message: "وقت النهاية يجب أن يكون بعد وقت البداية" };
  }
  
  // Calculate hours
  const [sh, sm] = data.startTime.split(":").map(Number);
  const [eh, em] = data.endTime.split(":").map(Number);
  const hours = (eh + em / 60) - (sh + sm / 60);
  if (hours <= 0) return { success: false, message: "مدة العمل الإضافي يجب أن تكون أكبر من صفر" };
  
  // Resolve workflow
  const workflow = resolveWorkflow("OVERTIME", data.employeeId, user.id);
  
  const assignment: OvertimeAssignment = {
    id: `ot-${idCounter++}`,
    number: `OT-2026-${String(idCounter).padStart(4, "0")}`,
    employeeId: data.employeeId,
    assignedBy: user.id,
    date: data.date,
    startTime: data.startTime,
    endTime: data.endTime,
    hours,
    reason: data.reason,
    notes: data.notes,
    status: workflow.status === "WORKFLOW_ERROR" ? "WORKFLOW_ERROR" : "PENDING_HR",
    currentApproverId: workflow.steps[0]?.approverUserId || null,
    workflowInstanceId: workflow.id,
    attachments: data.attachments || [],
    history: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  
  workflow.requestId = assignment.id;
  overtimeAssignments.push(assignment);
  
  // Add workflow history
  addWorkflowHistory(assignment.id, "OVERTIME", "DRAFT", assignment.status, "SUBMIT", user.id, "تم إنشاء التكليف");
  
  // Add notification for first approver
  if (workflow.steps[0]?.approverUserId) {
    addNotification(workflow.steps[0].approverUserId, "تكليف إضافي جديد", `تكليف إضافي جديد بانتظار موافقتك`, "OVERTIME", assignment.id);
  }
  
  addAuditLog(user.id, "CREATE", "OVERTIME", assignment.id);
  
  return { success: true, message: "تم إنشاء التكليف بنجاح", assignment };
}

export function getOvertimeAllowedActions(user: User, assignment: OvertimeAssignment): string[] {
  if (!assignment.workflowInstanceId) return [];
  const workflow = getWorkflowInstance(assignment.workflowInstanceId);
  if (!workflow) return [];
  return getWorkflowAllowedActions(user, workflow);
}

export function performOvertimeAction(user: User, assignmentId: string, action: string, comment?: string): { success: boolean; message: string } {
  const assignment = overtimeAssignments.find((a) => a.id === assignmentId);
  if (!assignment) return { success: false, message: "التكليف غير موجود" };
  if (!assignment.workflowInstanceId) return { success: false, message: "خطأ في مسار الموافقة" };
  
  const workflow = getWorkflowInstance(assignment.workflowInstanceId);
  if (!workflow) return { success: false, message: "خطأ في مسار الموافقة" };
  
  const result = performWorkflowAction(user, workflow, action, comment);
  if (result.success) {
    // Update assignment status based on workflow
    if (workflow.status === "APPROVED") {
      assignment.status = "APPROVED";
    } else if (workflow.status === "REJECTED") {
      assignment.status = "REJECTED";
    } else if (workflow.status === "PENDING_GM") {
      assignment.status = "PENDING_GM";
    } else if (workflow.status === "PENDING") {
      assignment.status = "PENDING_HR";
    }
    
    assignment.currentApproverId = workflow.steps[workflow.currentStepIndex]?.approverUserId || null;
    assignment.updatedAt = new Date().toISOString();
    
    // Add workflow history
    addWorkflowHistory(assignment.id, "OVERTIME", assignment.status, assignment.status, action, user.id, comment);
    
    // Add notification for next approver
    if (assignment.currentApproverId) {
      addNotification(assignment.currentApproverId, "تكليف إضافي", `تكليف إضافي بانتظار موافقتك`, "OVERTIME", assignment.id);
    }
  }
  
  return result;
}

// Inquiry functions
export function createInquiry(user: User, data: { category: string; subject: string; question: string; attachments?: Attachment[] }): { success: boolean; message: string } {
  const inquiry: Inquiry = {
    id: `inq-${idCounter++}`,
    number: `INQ-2026-${String(idCounter).padStart(4, "0")}`,
    employeeId: user.employeeId,
    category: data.category,
    subject: data.subject,
    question: data.question,
    status: "NEW",
    attachments: data.attachments || [],
    createdAt: new Date().toISOString(),
  };
  
  inquiries.push(inquiry);
  
  // Notify HR officers
  const hrOfficers = getHROfficers();
  for (const officer of hrOfficers) {
    const officerUser = users.find((u) => u.employeeId === officer.id);
    if (officerUser) {
      addNotification(officerUser.id, "استفسار جديد", `استفسار جديد من ${getEmployee(user.employeeId)?.name}`, "INQUIRY", inquiry.id);
    }
  }
  
  addAuditLog(user.id, "CREATE", "INQUIRY", inquiry.id);
  
  return { success: true, message: "تم إنشاء الاستفسار بنجاح" };
}

export function updateInquiryStatus(user: User, inquiryId: string, status: "IN_PROGRESS" | "ANSWERED" | "CLOSED", response?: string): { success: boolean; message: string } {
  if (!canViewAllInquiries(user.role)) {
    return { success: false, message: "غير مصرح لك بتنفيذ هذا الإجراء" };
  }
  
  const inquiry = inquiries.find((i) => i.id === inquiryId);
  if (!inquiry) return { success: false, message: "الاستفسار غير موجود" };
  
  inquiry.status = status;
  inquiry.assignedTo = user.id;
  if (response) inquiry.response = response;
  if (status === "CLOSED") inquiry.resolvedAt = new Date().toISOString();
  
  // Notify employee
  addNotification(inquiry.employeeId, "تحديث على استفسارك", `تم تحديث حالة استفسارك إلى ${getStatusLabel(status)}`, "INQUIRY", inquiry.id);
  
  addAuditLog(user.id, "UPDATE", "INQUIRY", inquiry.id, "NEW", status);
  
  return { success: true, message: "تم تحديث الاستفسار بنجاح" };
}

// Complaint functions
export function createComplaint(user: User, data: { category: string; subject: string; description: string; confidential: boolean; attachments?: Attachment[] }): { success: boolean; message: string } {
  const complaint: Complaint = {
    id: `comp-${idCounter++}`,
    number: `COMP-2026-${String(idCounter).padStart(4, "0")}`,
    employeeId: user.employeeId,
    category: data.category,
    subject: data.subject,
    description: data.description,
    confidential: data.confidential,
    status: "NEW",
    attachments: data.attachments || [],
    createdAt: new Date().toISOString(),
  };
  
  complaints.push(complaint);
  
  // Notify HR officers
  const hrOfficers = getHROfficers();
  for (const officer of hrOfficers) {
    const officerUser = users.find((u) => u.employeeId === officer.id);
    if (officerUser) {
      addNotification(officerUser.id, "شكوى جديدة", `شكوى جديدة من ${getEmployee(user.employeeId)?.name}`, "COMPLAINT", complaint.id);
    }
  }
  
  addAuditLog(user.id, "CREATE", "COMPLAINT", complaint.id);
  
  return { success: true, message: "تم إنشاء الشكوى بنجاح" };
}

export function updateComplaintStatus(user: User, complaintId: string, status: "IN_REVIEW" | "RESPONDED" | "CLOSED", response?: string): { success: boolean; message: string } {
  if (!canViewAllComplaints(user.role)) {
    return { success: false, message: "غير مصرح لك بتنفيذ هذا الإجراء" };
  }
  
  const complaint = complaints.find((c) => c.id === complaintId);
  if (!complaint) return { success: false, message: "الشكوى غير موجودة" };
  
  complaint.status = status;
  complaint.assignedTo = user.id;
  if (response) complaint.response = response;
  if (status === "CLOSED") complaint.closedAt = new Date().toISOString();
  
  // Notify employee
  addNotification(complaint.employeeId, "تحديث على شكواك", `تم تحديث حالة شكواك إلى ${getStatusLabel(status)}`, "COMPLAINT", complaint.id);
  
  addAuditLog(user.id, "UPDATE", "COMPLAINT", complaint.id, "NEW", status);
  
  return { success: true, message: "تم تحديث الشكوى بنجاح" };
}

// Announcement functions
export function createAnnouncement(user: User, data: {
  title: string;
  type: "ANNOUNCEMENT" | "CIRCULAR";
  message: string;
  targetType: "ALL" | "DEPARTMENT" | "SECTION" | "EMPLOYEE";
  targetId?: string;
  publishDate: string;
  expiryDate: string;
  attachments?: Attachment[];
}): { success: boolean; message: string } {
  if (!canCreateAnnouncements(user.role)) {
    return { success: false, message: "غير مصرح لك بإنشاء إعلان" };
  }
  
  const announcement: Announcement = {
    id: `ann-${idCounter++}`,
    title: data.title,
    type: data.type,
    message: data.message,
    targetType: data.targetType,
    targetId: data.targetId,
    createdBy: user.id,
    publishDate: data.publishDate,
    expiryDate: data.expiryDate,
    status: "PUBLISHED",
    attachments: data.attachments || [],
    createdAt: new Date().toISOString(),
  };
  
  announcements.push(announcement);
  
  // Notify targeted employees
  const targetEmployees = getTargetedEmployees(announcement);
  for (const emp of targetEmployees) {
    const empUser = users.find((u) => u.employeeId === emp.id);
    if (empUser) {
      addNotification(empUser.id, "إعلان جديد", data.title, "ANNOUNCEMENT", announcement.id);
    }
  }
  
  addAuditLog(user.id, "CREATE", "ANNOUNCEMENT", announcement.id);
  
  return { success: true, message: "تم إنشاء الإعلان بنجاح" };
}

function getTargetedEmployees(announcement: Announcement): Employee[] {
  switch (announcement.targetType) {
    case "ALL":
      return employees.filter((e) => e.active);
    case "DEPARTMENT":
      return employees.filter((e) => e.departmentId === announcement.targetId && e.active);
    case "SECTION":
      return employees.filter((e) => e.sectionId === announcement.targetId && e.active);
    case "EMPLOYEE":
      const emp = getEmployee(announcement.targetId || "");
      return emp ? [emp] : [];
    default:
      return [];
  }
}

export function isAnnouncementVisibleToUser(announcement: Announcement, user: User): boolean {
  const emp = getEmployee(user.employeeId);
  if (!emp) return false;
  
  switch (announcement.targetType) {
    case "ALL":
      return true;
    case "DEPARTMENT":
      return emp.departmentId === announcement.targetId;
    case "SECTION":
      return emp.sectionId === announcement.targetId;
    case "EMPLOYEE":
      return emp.id === announcement.targetId;
    default:
      return false;
  }
}

// Summons functions
export function createSummons(user: User, data: {
  employeeId: string;
  subject: string;
  date: string;
  time: string;
  location: string;
  message: string;
  attachments?: Attachment[];
}): { success: boolean; message: string } {
  if (!canCreateSummons(user.role)) {
    return { success: false, message: "غير مصرح لك بإنشاء استدعاء" };
  }
  
  const summons: Summons = {
    id: `sum-${idCounter++}`,
    number: `SUM-2026-${String(idCounter).padStart(4, "0")}`,
    employeeId: data.employeeId,
    subject: data.subject,
    date: data.date,
    time: data.time,
    location: data.location,
    message: data.message,
    createdBy: user.id,
    status: "ISSUED",
    attachments: data.attachments || [],
    createdAt: new Date().toISOString(),
  };
  
  summonsList.push(summons);
  
  // Notify employee
  addNotification(data.employeeId, "استدعاء", `لديك استدعاء: ${data.subject}`, "SUMMONS", summons.id);
  
  addAuditLog(user.id, "CREATE", "SUMMONS", summons.id);
  
  return { success: true, message: "تم إنشاء الاستدعاء بنجاح" };
}

// Notification functions
function addNotification(recipientId: string, title: string, message: string, type: string, referenceId?: string): void {
  notifications.push({
    id: `notif-${idCounter++}`,
    recipientId,
    title,
    message,
    type,
    referenceId,
    read: false,
    createdAt: new Date().toISOString(),
  });
}

export function getNotifications(userId: string): Notification[] {
  return notifications.filter((n) => n.recipientId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getUnreadCount(userId: string): number {
  return notifications.filter((n) => n.recipientId === userId && !n.read).length;
}

export function markNotificationRead(notificationId: string): void {
  const notification = notifications.find((n) => n.id === notificationId);
  if (notification) notification.read = true;
}

export function markAllNotificationsRead(userId: string): void {
  notifications.forEach((n) => {
    if (n.recipientId === userId) n.read = true;
  });
}

// Workflow history functions
function addWorkflowHistory(requestId: string, requestType: string, fromStatus: string, toStatus: string, action: string, performedBy: string, comment?: string): void {
  const history: WorkflowHistory = {
    id: `hist-${idCounter++}`,
    requestType,
    requestId,
    fromStatus,
    toStatus,
    action,
    performedBy,
    comment,
    timestamp: new Date().toISOString(),
  };
  
  // Add to the appropriate request
  if (requestType === "LEAVE") {
    const request = leaveRequests.find((r) => r.id === requestId);
    if (request) request.history.push(history);
  } else if (requestType === "OVERTIME") {
    const assignment = overtimeAssignments.find((a) => a.id === requestId);
    if (assignment) assignment.history.push(history);
  }
}

// Audit log functions
function addAuditLog(userId: string, action: string, entityType: string, entityId: string, oldValue?: string, newValue?: string): void {
  auditLogs.push({
    id: `audit-${idCounter++}`,
    userId,
    action,
    entityType,
    entityId,
    oldValue,
    newValue,
    timestamp: new Date().toISOString(),
  });
}

export function getAuditLogs(): AuditLog[] {
  return [...auditLogs].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
}

// User management functions
export function createUser(user: User, data: {
  username: string;
  password: string;
  email: string;
  role: Role;
  employeeId: string;
}): { success: boolean; message: string } {
  if (!canManageUsers(user.role)) {
    return { success: false, message: "غير مصرح لك بإنشاء مستخدم" };
  }

  // Check if username already exists
  if (users.find((u) => u.username === data.username)) {
    return { success: false, message: "اسم المستخدم موجود بالفعل" };
  }

  // Check if employee already has a user
  if (users.find((u) => u.employeeId === data.employeeId)) {
    return { success: false, message: "هذا الموظف لديه حساب بالفعل" };
  }

  const newUser: User = {
    id: `user-${idCounter++}`,
    username: data.username,
    password: data.password,
    email: data.email,
    role: data.role,
    employeeId: data.employeeId,
    active: true,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  addAuditLog(user.id, "CREATE", "USER", newUser.id);
  
  return { success: true, message: "تم إنشاء المستخدم بنجاح" };
}

export function updateUserRole(adminUser: User, userId: string, newRole: Role): { success: boolean; message: string } {
  if (!canManageUsers(adminUser.role)) {
    return { success: false, message: "غير مصرح لك بتغيير الأدوار" };
  }

  const targetUser = users.find((u) => u.id === userId);
  if (!targetUser) {
    return { success: false, message: "المستخدم غير موجود" };
  }

  const oldRole = targetUser.role;
  targetUser.role = newRole;
  
  addAuditLog(adminUser.id, "ROLE_CHANGE", "USER", userId, oldRole, newRole);
  
  return { success: true, message: "تم تحديث دور المستخدم بنجاح" };
}

export function toggleUserActive(adminUser: User, userId: string): { success: boolean; message: string } {
  if (!canManageUsers(adminUser.role)) {
    return { success: false, message: "غير مصرح لك بتعديل حالة المستخدم" };
  }

  const targetUser = users.find((u) => u.id === userId);
  if (!targetUser) {
    return { success: false, message: "المستخدم غير موجود" };
  }

  targetUser.active = !targetUser.active;
  
  addAuditLog(adminUser.id, targetUser.active ? "ACTIVATE" : "DEACTIVATE", "USER", userId);
  
  return { success: true, message: targetUser.active ? "تم تفعيل المستخدم" : "تم تعطيل المستخدم" };
}

export function resetPassword(adminUser: User, userId: string, newPassword: string): { success: boolean; message: string } {
  if (!canManageUsers(adminUser.role)) {
    return { success: false, message: "غير مصرح لك بإعادة تعيين كلمة المرور" };
  }

  const targetUser = users.find((u) => u.id === userId);
  if (!targetUser) {
    return { success: false, message: "المستخدم غير موجود" };
  }

  targetUser.password = newPassword;
  
  addAuditLog(adminUser.id, "PASSWORD_RESET", "USER", userId);
  
  return { success: true, message: "تم إعادة تعيين كلمة المرور بنجاح" };
}

// Organization management functions
export function createOrgUnit(user: User, data: {
  name: string;
  code: string;
  type: "COMPANY" | "DEPARTMENT" | "SECTION";
  parentId: string | null;
  managerId: string | null;
}): { success: boolean; message: string } {
  if (!canManageOrg(user.role)) {
    return { success: false, message: "غير مصرح لك بإدارة الهيكل التنظيمي" };
  }

  const newUnit: OrgUnit = {
    id: `unit-${idCounter++}`,
    name: data.name,
    code: data.code,
    type: data.type,
    parentId: data.parentId,
    managerId: data.managerId,
    active: true,
  };

  orgUnits.push(newUnit);
  addAuditLog(user.id, "CREATE", "ORG_UNIT", newUnit.id);
  
  return { success: true, message: "تم إنشاء الوحدة التنظيمية بنجاح" };
}

export function updateOrgUnitManager(user: User, unitId: string, managerId: string | null): { success: boolean; message: string } {
  if (!canManageOrg(user.role)) {
    return { success: false, message: "غير مصرح لك بتعديل الهيكل التنظيمي" };
  }

  const unit = orgUnits.find((u) => u.id === unitId);
  if (!unit) {
    return { success: false, message: "الوحدة التنظيمية غير موجودة" };
  }

  const oldManager = unit.managerId;
  unit.managerId = managerId;
  
  addAuditLog(user.id, "UPDATE", "ORG_UNIT", unitId, oldManager || "", managerId || "");
  
  return { success: true, message: "تم تحديث مدير الوحدة بنجاح" };
}

export function updateEmployeeManager(user: User, employeeId: string, managerId: string | null): { success: boolean; message: string } {
  if (!canManageOrg(user.role)) {
    return { success: false, message: "غير مصرح لك بتعديل بيانات الموظف" };
  }

  const employee = employees.find((e) => e.id === employeeId);
  if (!employee) {
    return { success: false, message: "الموظف غير موجود" };
  }

  const oldManager = employee.managerId;
  employee.managerId = managerId;
  
  addAuditLog(user.id, "UPDATE", "EMPLOYEE", employeeId, oldManager || "", managerId || "");
  
  return { success: true, message: "تم تحديث المدير المباشر بنجاح" };
}

export function updateEmployeeDepartment(user: User, employeeId: string, departmentId: string | null): { success: boolean; message: string } {
  if (!canManageOrg(user.role)) {
    return { success: false, message: "غير مصرح لك بتعديل بيانات الموظف" };
  }

  const employee = employees.find((e) => e.id === employeeId);
  if (!employee) {
    return { success: false, message: "الموظف غير موجود" };
  }

  const oldDept = employee.departmentId;
  employee.departmentId = departmentId;
  
  addAuditLog(user.id, "UPDATE", "EMPLOYEE", employeeId, oldDept || "", departmentId || "");
  
  return { success: true, message: "تم تحديث إدارة الموظف بنجاح" };
}

export function updateEmployeeSection(user: User, employeeId: string, sectionId: string | null): { success: boolean; message: string } {
  if (!canManageOrg(user.role)) {
    return { success: false, message: "غير مصرح لك بتعديل بيانات الموظف" };
  }

  const employee = employees.find((e) => e.id === employeeId);
  if (!employee) {
    return { success: false, message: "الموظف غير موجود" };
  }

  const oldSection = employee.sectionId;
  employee.sectionId = sectionId;
  
  addAuditLog(user.id, "UPDATE", "EMPLOYEE", employeeId, oldSection || "", sectionId || "");
  
  return { success: true, message: "تم تحديث قسم الموظف بنجاح" };
}

// Data store for components
export const dataStore = {
  get employees() { return employees; },
  get users() { return users; },
  get orgUnits() { return orgUnits; },
  get leaveTypes() { return leaveTypes; },
  get leaveRequests() { return leaveRequests; },
  get overtime() { return overtimeAssignments; },
  get inquiries() { return inquiries; },
  get complaints() { return complaints; },
  get announcements() { return announcements; },
  get summons() { return summonsList; },
  get notifications() { return notifications; },
  get auditLogs() { return auditLogs; },
  get workflowInstances() { return workflowInstances; },
};