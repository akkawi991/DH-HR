import { getEmployee, getRoleLabel } from "@/lib/data";
import type { User } from "@/lib/data";

interface NavItem {
  id: string;
  label: string;
  icon: string;
}

interface SidebarProps {
  navItems: NavItem[];
  currentPage: string;
  onNavigate: (page: string) => void;
  user: User;
}

export function Sidebar({ navItems, currentPage, onNavigate, user }: SidebarProps) {
  const emp = getEmployee(user.employeeId);

  const getIcon = (icon: string) => {
    switch (icon) {
      case "home": return "🏠";
      case "calendar": return "📅";
      case "clock": return "⏰";
      case "help": return "❓";
      case "alert": return "⚠️";
      case "megaphone": return "📢";
      case "file": return "📄";
      case "users": return "👥";
      case "user": return "👤";
      case "tree": return "🌳";
      case "check": return "✅";
      case "bell": return "🔔";
      default: return "📋";
    }
  };

  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col min-h-screen">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-lg">
            DH
          </div>
          <div>
            <div className="font-bold text-lg">DH HR</div>
            <div className="text-xs text-slate-400">خدمات الموظفين</div>
          </div>
        </div>
      </div>

      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center font-bold">
            {emp?.name?.charAt(0) || "؟"}
          </div>
          <div>
            <div className="text-sm font-medium">{emp?.name}</div>
            <div className="text-xs text-slate-400">{getRoleLabel(user.role)}</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm transition-colors ${
              currentPage === item.id
                ? "bg-indigo-600 text-white"
                : "text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <span className="text-lg">{getIcon(item.icon)}</span>
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800 text-xs text-slate-500">
        DH HR v1.0.0
      </div>
    </aside>
  );
}