import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getLeaveType,
  getStatusLabel,
  getStatusColor,
  getScopeEmployeeIds,
  canCreateLeaveForOthers,
  createLeaveRequest,
  getLeaveAllowedActions,
  performLeaveAction,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface LeaveRequestsProps {
  user: User;
}

export function LeaveRequests({ user }: LeaveRequestsProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);

  const scopeIds = getScopeEmployeeIds(user);
  const canCreateForOthers = canCreateLeaveForOthers(user.role);
  const visibleRequests = dataStore.leaveRequests.filter((r) => scopeIds.includes(r.employeeId));

  const handleAction = (requestId: string, action: string) => {
    let comment: string | undefined;
    if (action === "REJECT" || action === "FORWARD") {
      comment = prompt(action === "REJECT" ? "سبب الرفض:" : "سبب التحويل:");
      if (!comment) return;
    }
    const result = performLeaveAction(user, requestId, action, comment);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الإجازات</h1>
          <p className="text-slate-500 mt-1">إدارة طلبات الإجازة</p>
        </div>
        <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
          طلب إجازة
        </Button>
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">طلبات الإجازة ({visibleRequests.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {visibleRequests.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد طلبات إجازة</p>
          ) : (
            <div className="space-y-4">
              {visibleRequests.map((request) => {
                const emp = getEmployee(request.employeeId);
                const leaveType = getLeaveType(request.leaveTypeId);
                const actions = getLeaveAllowedActions(user, request);
                return (
                  <div key={request.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{request.number}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(request.status)}`}>
                        {getStatusLabel(request.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div>الموظف: {emp?.name}</div>
                      <div>النوع: {leaveType?.name}</div>
                      <div>المدة: {request.days > 0 ? `${request.days} يوم` : `${request.hours} ساعة`}</div>
                      <div>السبب: {request.reason}</div>
                    </div>
                    {actions.length > 0 && (
                      <div className="flex gap-2 mt-3">
                        {actions.includes("APPROVE") && (
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-700"
                            onClick={() => handleAction(request.id, "APPROVE")}
                          >
                            موافقة
                          </Button>
                        )}
                        {actions.includes("REJECT") && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleAction(request.id, "REJECT")}
                          >
                            رفض
                          </Button>
                        )}
                        {actions.includes("FORWARD") && (
                          <Button
                            size="sm"
                            className="bg-purple-600 hover:bg-purple-700"
                            onClick={() => handleAction(request.id, "FORWARD")}
                          >
                            تحويل للمدير العام
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {showForm && (
        <LeaveForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => {
            setShowForm(false);
            setRefresh(refresh + 1);
          }}
        />
      )}
    </div>
  );
}

function LeaveForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [employeeId, setEmployeeId] = useState(user.employeeId);
  const [leaveTypeId, setLeaveTypeId] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");

  const canCreateForOthers = canCreateLeaveForOthers(user.role);
  const scopeIds = getScopeEmployeeIds(user);
  const selectedLeaveType = dataStore.leaveTypes.find((lt) => lt.id === leaveTypeId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createLeaveRequest(user, {
      employeeId,
      leaveTypeId,
      startDate,
      endDate,
      startTime,
      endTime,
      reason,
    });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">طلب إجازة</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          {canCreateForOthers && (
            <div>
              <label className="block text-sm font-medium mb-1">الموظف *</label>
              <select
                value={employeeId}
                onChange={(e) => setEmployeeId(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              >
                <option value="">اختر الموظف</option>
                {dataStore.employees
                  .filter((e) => scopeIds.includes(e.id) && e.active)
                  .map((emp) => (
                    <option key={emp.id} value={emp.id}>{emp.name}</option>
                  ))}
              </select>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium mb-1">نوع الإجازة *</label>
            <select
              value={leaveTypeId}
              onChange={(e) => setLeaveTypeId(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="">اختر نوع الإجازة</option>
              {dataStore.leaveTypes.filter((lt) => lt.active).map((lt) => (
                <option key={lt.id} value={lt.id}>{lt.name}</option>
              ))}
            </select>
          </div>
          {selectedLeaveType?.unitType === "DAYS" ? (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">تاريخ البداية *</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">تاريخ النهاية *</label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                  required
                />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">التاريخ *</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">من *</label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">إلى *</label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full p-2 border rounded-lg"
                  required
                />
              </div>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium mb-1">السبب *</label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full p-2 border rounded-lg"
              rows={3}
              required
            />
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">إرسال</Button>
          </div>
        </form>
      </div>
    </div>
  );
}