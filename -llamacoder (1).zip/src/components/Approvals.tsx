import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getLeaveType,
  getStatusLabel,
  getStatusColor,
  getLeaveAllowedActions,
  performLeaveAction,
  getOvertimeAllowedActions,
  performOvertimeAction,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface ApprovalsProps {
  user: User;
}

export function Approvals({ user }: ApprovalsProps) {
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);

  // Get leave requests where user is the current approver
  const pendingLeaves = dataStore.leaveRequests.filter((r) => {
    const actions = getLeaveAllowedActions(user, r);
    return actions.length > 0;
  });

  // Get overtime assignments where user is the current approver
  const pendingOvertime = dataStore.overtime.filter((o) => {
    const actions = getOvertimeAllowedActions(user, o);
    return actions.length > 0;
  });

  const handleLeaveAction = (requestId: string, action: string) => {
    let comment: string | undefined;
    if (action === "REJECT" || action === "FORWARD") {
      comment = prompt(action === "REJECT" ? "سبب الرفض:" : "سبب التحويل:");
      if (!comment) return;
    }
    const result = performLeaveAction(user, requestId, action, comment);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  const handleOvertimeAction = (assignmentId: string, action: string) => {
    let comment: string | undefined;
    if (action === "REJECT") {
      comment = prompt("سبب الرفض:");
      if (!comment) return;
    }
    const result = performOvertimeAction(user, assignmentId, action, comment);
    if (result.success) {
      setRefresh(refresh + 1);
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">الموافقات</h1>
        <p className="text-slate-500 mt-1">الطلبات بانتظار موافقتك</p>
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">طلبات الإجازة ({pendingLeaves.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {pendingLeaves.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد طلبات إجازة بانتظار موافقتك</p>
          ) : (
            <div className="space-y-4">
              {pendingLeaves.map((request) => {
                const emp = getEmployee(request.employeeId);
                const leaveType = getLeaveType(request.leaveTypeId);
                const actions = getLeaveAllowedActions(user, request);
                return (
                  <div key={request.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{request.number}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(request.status)}`}>
                        {getStatusLabel(request.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div>الموظف: {emp?.name}</div>
                      <div>النوع: {leaveType?.name}</div>
                      <div>المدة: {request.days > 0 ? `${request.days} يوم` : `${request.hours} ساعة`}</div>
                      <div>السبب: {request.reason}</div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      {actions.includes("APPROVE") && (
                        <Button
                          size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => handleLeaveAction(request.id, "APPROVE")}
                        >
                          موافقة
                        </Button>
                      )}
                      {actions.includes("REJECT") && (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleLeaveAction(request.id, "REJECT")}
                        >
                          رفض
                        </Button>
                      )}
                      {actions.includes("FORWARD") && (
                        <Button
                          size="sm"
                          className="bg-purple-600 hover:bg-purple-700"
                          onClick={() => handleLeaveAction(request.id, "FORWARD")}
                        >
                          تحويل للمدير العام
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">تكليفات العمل الإضافي ({pendingOvertime.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {pendingOvertime.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد تكليفات بانتظار موافقتك</p>
          ) : (
            <div className="space-y-4">
              {pendingOvertime.map((assignment) => {
                const emp = getEmployee(assignment.employeeId);
                const actions = getOvertimeAllowedActions(user, assignment);
                return (
                  <div key={assignment.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{assignment.number}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(assignment.status)}`}>
                        {getStatusLabel(assignment.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div>الموظف: {emp?.name}</div>
                      <div>التاريخ: {assignment.date}</div>
                      <div>الوقت: {assignment.startTime} - {assignment.endTime}</div>
                      <div>الساعات: {assignment.hours}</div>
                      <div>السبب: {assignment.reason}</div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      {actions.includes("APPROVE") && (
                        <Button
                          size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700"
                          onClick={() => handleOvertimeAction(assignment.id, "APPROVE")}
                        >
                          موافقة
                        </Button>
                      )}
                      {actions.includes("REJECT") && (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleOvertimeAction(assignment.id, "REJECT")}
                        >
                          رفض
                        </Button>
                      )}
                      {actions.includes("FORWARD") && (
                        <Button
                          size="sm"
                          className="bg-purple-600 hover:bg-purple-700"
                          onClick={() => handleOvertimeAction(assignment.id, "FORWARD")}
                        >
                          تحويل للمدير العام
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}