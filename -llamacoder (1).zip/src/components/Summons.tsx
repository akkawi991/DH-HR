import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  dataStore,
  getEmployee,
  getStatusLabel,
  getStatusColor,
  canCreateSummons,
  createSummons,
} from "@/lib/data";
import type { User } from "@/lib/data";

interface SummonsProps {
  user: User;
}

export function Summons({ user }: SummonsProps) {
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");

  const canCreate = canCreateSummons(user.role);
  const visibleSummons = dataStore.summons.filter((s) => {
    if (canCreate) return true;
    return s.employeeId === user.employeeId;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">الاستدعاءات</h1>
          <p className="text-slate-500 mt-1">إدارة استدعاءات الموظفين</p>
        </div>
        {canCreate && (
          <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => setShowForm(true)}>
            استدعاء موظف
          </Button>
        )}
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">الاستدعاءات ({visibleSummons.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {visibleSummons.length === 0 ? (
            <p className="text-slate-500 text-sm">لا توجد استدعاءات</p>
          ) : (
            <div className="space-y-4">
              {visibleSummons.map((sum) => {
                const emp = getEmployee(sum.employeeId);
                return (
                  <div key={sum.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{sum.number}</div>
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(sum.status)}`}>
                        {getStatusLabel(sum.status)}
                      </span>
                    </div>
                    <div className="text-sm text-slate-600">
                      <div>الموظف: {emp?.name}</div>
                      <div>الموضوع: {sum.subject}</div>
                      <div>التاريخ: {sum.date} - {sum.time}</div>
                      <div>المكان: {sum.location}</div>
                      <div className="mt-2">{sum.message}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {showForm && (
        <SummonsForm
          user={user}
          onClose={() => setShowForm(false)}
          onSuccess={() => setShowForm(false)}
        />
      )}
    </div>
  );
}

function SummonsForm({ user, onClose, onSuccess }: { user: User; onClose: () => void; onSuccess: () => void }) {
  const [employeeId, setEmployeeId] = useState("");
  const [subject, setSubject] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [location, setLocation] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = createSummons(user, {
      employeeId,
      subject,
      date,
      time,
      location,
      message,
    });
    if (result.success) {
      onSuccess();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold">استدعاء موظف</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 text-slate-500"
          >
            ×
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">الموظف *</label>
            <select
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="">اختر الموظف</option>
              {dataStore.employees.filter((e) => e.active).map((emp) => (
                <option key={emp.id} value={emp.id}>{emp.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الموضوع *</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">التاريخ *</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">الوقت *</label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full p-2 border rounded-lg"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">المكان *</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">الرسالة *</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-2 border rounded-lg"
              rows={3}
              required
            />
          </div>
          {error && <div className="bg-red-50 text-red-700 text-sm p-3 rounded-lg">{error}</div>}
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">إصدار</Button>
          </div>
        </form>
      </div>
    </div>
  );
}